<?php

include (dirname(__FILE__).'/../Libs/kpf/flowAPI.php');

class Tuxpan_FlowPayment_CheckoutController extends Mage_Core_Controller_Front_Action
{
	public function gatewayAction()
	{
		$orderId = Mage::getSingleton('checkout/session')->getLastRealOrderId();
		$order = Mage::getSingleton('sales/order')->loadByIncrementId($orderId);

		$orden_compra = $orderId;
		$monto = $order->getGrandTotal();
		$concepto = 'Orden #'.$orderId.' - '.Mage::app()->getStore()->getName();
		$email_pagador = $order->getCustomerEmail();

		$flowAPI = $this->getFlowAPI();
		try {
			$flow_pack = $flowAPI->new_order($orden_compra, $monto, $concepto, $email_pagador);
		} catch (Exception $e) {
			echo($e);
		}

		$flow_url_pago = $this->getConfigValue('flow_url');
		echo '
		<html>
			<head></head>
			<body onload="sendData();">
				<form id="flowForm" method="post" action="'.$flow_url_pago.'">
					<input type="hidden" name="parameters" value="'.$flow_pack.'" />
				</form>
				<script type="text/javascript">
					function sendData() {
						var form = document.getElementById("flowForm");
						form.submit();
					}
				</script>
			</body>
		</html>
		';
	}

	public function indexAction()
	{
		Mage_Core_Controller_Varien_Action::_redirect('', array('_secure'=> false));
	}

	public function confirmAction()
	{
		$flowAPI = $this->getFlowAPI();
		$response = null;

		try {
			$flowAPI->read_confirm();

			$orderId = intval($flowAPI->getOrderNumber());
			$order = Mage::getModel('sales/order')->loadByIncrementId($orderId);

			$paymentState = $flowAPI->getStatus() == "EXITO";
			$response =  $flowAPI->build_response($paymentState);

			if($paymentState) {
	      		$order->setState($this->getConfigValue('flow_order_status_success'), $this->getConfigValue('flow_order_status_success'), 'Flow - Payment Succesful');
			} else {
	      		$order->setState($this->getConfigValue('order_status_fail'), $this->getConfigValue('order_status_fail'), 'Flow - Payment Failed');
			}
			$order->save();
			Mage::getSingleton('checkout/session')->unsQuoteId();
		} catch (Exception $e) {
			$flowAPI->flow_log($e->toString(), "confirm_error");
			$response = $flowAPI ->build_response(false);
		}

		echo $response;
	}

	public function successAction()
	{
		Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/success', array('_secure'=> false));
	}

	public function failAction()
	{
		Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/failure', array('_secure'=> false));
	}

	private function getFlowAPI() 
	{
		$flowAPI = new flowAPI();
		
		$flowAPI->setMedioPago($this->getConfigValue('medio_pago'));
		$flowAPI->setComercio($this->getConfigValue('id_comercio'));
		$flowAPI->setURLExito(Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB).'index.php/flowpayment/checkout/success');
		$flowAPI->setURLFracaso(Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB).'index.php/flowpayment/checkout/fail');
		$flowAPI->setURLConfirmacion(Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB).'index.php/flowpayment/checkout/confirm');
		$flowAPI->setTipoIntegracion($this->getConfigValue('tipo_integracion'));
		$flowAPI->setKeyCommerce($this->getConfigValue('certificate'));
		$flowAPI->setKeysFolder(Mage::getBaseDir('base').'/var/uploads/flow');
		$flowAPI->setLogFolder(Mage::getBaseDir('base').'/var/log');
		return $flowAPI;
	}

	private function getConfigValue($key) 
	{
		return Mage::getStoreConfig('payment/flowpayment/'.$key, Mage::app()->getStore()); 
	}

}