<?php

class Tuxpan_FlowPayment_Model_System_Config_Source_MedioPago
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return array(
            array('value' => '9', 'label' => Mage::helper('flowpayment')->__('All payment methods')),
            array('value' => '1', 'label' => Mage::helper('flowpayment')->__('Only Webpay')),
            array('value' => '2', 'label' => Mage::helper('flowpayment')->__('Only Servipag'))
        );
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return array(
            '9' => Mage::helper('flowpayment')->__('All payment methods'),
            '1' => Mage::helper('flowpayment')->__('Only Webpay'),
            '2' => Mage::helper('flowpayment')->__('Only Servipag')
        );
    }
}