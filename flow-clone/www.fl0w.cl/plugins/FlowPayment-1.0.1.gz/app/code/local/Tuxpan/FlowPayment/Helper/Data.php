<?php

class Tuxpan_FlowPayment_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}