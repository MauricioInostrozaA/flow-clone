<?php

class Tuxpan_FlowPayment_Model_System_Config_Source_Ambiente
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return array(
            array('value' => 'http://flow.tuxpan.com/app/kpf/pago.php', 'label' => Mage::helper('flowpayment')->__('Test')),
            array('value' => 'https://www.flow.cl/app/kpf/pago.php', 'label' => Mage::helper('flowpayment')->__('Production'))
        );
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return array(
            'http://flow.tuxpan.com/app/kpf/pago.php' => Mage::helper('flowpayment')->__('Test'),
            'https://www.flow.cl/app/kpf/pago.php' => Mage::helper('flowpayment')->__('Production')
        );
    }
}