<?php

class Tuxpan_FlowPayment_Model_Payment extends Mage_Payment_Model_Method_Abstract {

	protected $_code  = 'flowpayment';
  protected $_formBlockType = 'flowpayment/form_flowPayment';
  protected $_infoBlockType = 'flowpayment/info_flowPayment';

  public function validate()
  {
      return true;
  }

	public function getOrderPlaceRedirectUrl()
	{
		return Mage::getUrl('flowpayment/checkout/gateway', array('_secure' => false));
	}

	public function getCode() {
		return $this->_code;
	}
}