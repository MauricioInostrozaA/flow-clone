<?php

class Tuxpan_FlowPayment_Model_System_Config_Backend_File extends Mage_Adminhtml_Model_System_Config_Backend_File
{
    public $extension = null;

    protected function _getFilename() 
    {
    	return null;
    }

    protected function _deleteOlderFile()
    {
    	$filename = Mage::getBaseDir('base').'/var/uploads/flow/'.$this->_getFilename();

        if($this->extension != null) {
            $filename .= $this->extension;
        }

		if(file_exists($filename) && is_file($filename)) 
		{
			unlink($filename);
		}
    }

    protected function _beforeSave()
    {
        $value = $this->getValue();
        if ($_FILES['groups']['tmp_name'][$this->getGroupId()]['fields'][$this->getField()]['value']) {

            $uploadDir = $this->_getUploadDir();

            try {
                $file             = array();
                $tmpName          = $_FILES['groups']['tmp_name'];
                $file['tmp_name'] = $tmpName[$this->getGroupId()]['fields'][$this->getField()]['value'];
                $name             = $_FILES['groups']['name'];
                $file['name']     = $name[$this->getGroupId()]['fields'][$this->getField()]['value'];
                $uploader         = new Mage_Core_Model_File_Uploader($file);
                $uploader->setAllowedExtensions($this->_getAllowedExtensions());
                $uploader->setAllowRenameFiles(TRUE);
                $uploader->addValidateCallback('size', $this, 'validateMaxSize');
                
                if(count($this->_getAllowedExtensions()) > 1) {
                    $ext    = explode('.', $file['name']);
                    $ext    = array_pop($ext);
                    $newfilename = $this->_getFilename().'.'.$ext;
                    $this->extension = $ext;
                } else {
                    $this->extension = null;
                    $newfilename = $this->_getFilename();
                }

				$this->_deleteOlderFile();

                $result = $uploader->save($uploadDir, $newfilename);

            } catch (Exception $e) {
                Mage::throwException($e->getMessage());
                return $this;
            }

            $filename = $result['file'];
            if ($filename) {
                if ($this->_addWhetherScopeInfo()) {
                    $filename = $this->_prependScopeInfo($filename);
                }
                $this->setValue($filename);
            }
        } else {
            if (is_array($value) && !empty($value['delete'])) {
                $this->setValue('');
            } else {
                $this->unsValue();
            }
        }

        return $this;
    }
}