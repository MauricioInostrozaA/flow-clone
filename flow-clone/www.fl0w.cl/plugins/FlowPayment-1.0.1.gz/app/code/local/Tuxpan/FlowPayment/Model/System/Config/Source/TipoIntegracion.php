<?php

class Tuxpan_FlowPayment_Model_System_Config_Source_TipoIntegracion
{
    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return array(
            array('value' => 'f', 'label' => Mage::helper('flowpayment')->__('Indirect')),
            array('value' => 'd', 'label' => Mage::helper('flowpayment')->__('Direct'))
        );
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return array(
            'f' => Mage::helper('flowpayment')->__('Indirect'),
            'd' => Mage::helper('flowpayment')->__('Direct')
        );
    }
}