<?php

class Tuxpan_FlowPayment_Model_System_Config_Backend_Image extends Mage_Adminhtml_Model_System_Config_Backend_File
{
    protected function _getAllowedExtensions()
    {
        return array('png', 'jpg', 'jpeg', 'gif');
    }
}