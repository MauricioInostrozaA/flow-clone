<?php

class Tuxpan_FlowPayment_Block_Form_FlowPayment extends Mage_Payment_Block_Form
{
  protected function _construct()
  	{
		  parent::_construct();
    	$this->setTemplate('flowpayment/form/flowpayment.phtml');
  	}

    public function setMethod($method)
    {
        return $this;
    }

    public function getMethod() 
    {
    	return "flowpayment";
    }

    public function getImageUrl() 
    {
      $filename = Mage::getBaseDir('base').'/media/flowpayment/'.Mage::getStoreConfig('payment/flowpayment/logo', Mage::app()->getStore());
      $image_url = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/flowpayment/';
      if(file_exists($filename) && is_file($filename))  {
        $image_url .= Mage::getStoreConfig('payment/flowpayment/logo', Mage::app()->getStore());
      } else {
        $image_url .= 'logo.png';
      }

      return $image_url; 
    }

    public function getDescripcion() 
    {
      return Mage::getStoreConfig('payment/flowpayment/descripcion', Mage::app()->getStore()); 
    }
}
