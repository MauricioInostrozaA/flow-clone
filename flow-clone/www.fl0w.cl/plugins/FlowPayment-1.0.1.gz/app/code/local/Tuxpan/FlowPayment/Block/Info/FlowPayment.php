<?php

class Tuxpan_FlowPayment_Block_Info_FlowPayment extends Mage_Payment_Block_Info
{
	
}