<?php

class Tuxpan_FlowPayment_Model_System_Config_Backend_Pem extends Mage_Adminhtml_Model_System_Config_Backend_File
{
    protected function _getAllowedExtensions()
    {
        return array('pem');
    }
}