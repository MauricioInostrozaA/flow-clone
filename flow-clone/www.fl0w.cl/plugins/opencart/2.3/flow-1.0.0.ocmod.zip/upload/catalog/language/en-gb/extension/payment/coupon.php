<?php

$_['coupon_message'] = 'Your coupon has been generated successfully';
$_['coupon_message_breadcrumb'] = 'Coupon generated';
$_['heading_title'] = 'Your coupon was generated';
$_['coupon_title'] = 'Coupon';
