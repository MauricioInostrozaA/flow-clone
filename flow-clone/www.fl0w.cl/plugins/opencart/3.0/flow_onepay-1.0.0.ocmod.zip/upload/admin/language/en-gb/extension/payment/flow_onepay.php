<?php

// Heading
$_['heading_title']                 = 'Flow Onepay';
$_['text_edit']						= 'Edit Flow payment settings';

// Text Extension Tuxpan
$_['text_payment']					= 'Payment';
$_['text_success']					= 'Success: You have modified Flow details!';
$_['text_flow_onepay']						= '<a onclick="window.open(\'https://www.flow.cl\');"><img width="125" height="25" src="view/image/payment/flow_onepay.png" alt="flow" title="flow" style="border: 1px solid #EEEEEE;" /></a>';
$_['has_private_key']				= 'You already have registered a private key. Choose another file if you want to update it';
$_['flow_test_site']				= 'Flow sandbox platform';
$_['flow_site']						= 'Flow production platform';
$_['text_multicaja']				= "Multicaja";
$_['text_servipag']					= "Servipag";
$_['text_flowmethod']				= "Flow";

// Entry Extension Tuxpan
$_['entry_apikey']					= 'Flow API Key:';
$_['entry_secret']					= 'Flow private key';
$_['entry_apiurl']					= 'Flow platform';
$_['entry_approved_status']			= 'Payment approved status';
$_['entry_failed_status']			= 'Payment failed status';
$_['entry_status']					= 'Status';
$_['entry_payment_name']			= 'Flow payment name';
$_['entry_sort_order']			    = 'Sort Order';
$_['entry_geo_zone']			    = 'Geo Zone';
$_['entry_prefix']			    	= 'Prefix';
$_['entry_urlreturn']			    = 'Return URL';


$_['error_apikey']					= 'API Key required';
$_['error_secret']					= 'Secret Key required';
$_['error_apiurl']					= 'API URL required';
$_['error_baseurl']					= 'Base URL required';
$_['error_payment_name']            = 'Payment Name required';
?>