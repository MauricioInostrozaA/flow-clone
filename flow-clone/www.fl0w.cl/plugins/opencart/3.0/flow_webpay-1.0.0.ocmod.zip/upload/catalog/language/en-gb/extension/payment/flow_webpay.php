<?php
// Text
$_['text_title'] = 'Flow Webpay';
$_['flow_page_title'] = 'Flow Webpay';
$_['flow_generic_error_message'] = 'There has been an unexpected error. Please try again.';
$_['flow_custom_error_breadcrumb'] = 'Error';