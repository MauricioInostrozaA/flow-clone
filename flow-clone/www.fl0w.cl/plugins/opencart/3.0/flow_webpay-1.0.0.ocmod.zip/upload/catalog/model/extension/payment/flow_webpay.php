<?php
class ModelExtensionPaymentFlowWebpay extends Model {
	public function getMethod($address, $total) {
        $this->load->language('extension/payment/flow_webpay');

		$method_data = array(
			'code'       => 'flow_webpay',
			'title'      => $this->language->get('text_title'),
			'terms'      => '',
			'sort_order' => $this->config->get('payment_flow_webpay_sort_order')
		);
        return $method_data;
    }
}
