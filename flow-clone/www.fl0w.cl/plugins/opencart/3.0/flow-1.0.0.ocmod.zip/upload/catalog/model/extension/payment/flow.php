<?php
class ModelExtensionPaymentFlow extends Model {
	public function getMethod($address, $total) {
        $this->load->language('extension/payment/flow');

		$method_data = array(
			'code'       => 'flow',
			'title'      => $this->language->get('text_title'),
			'terms'      => '',
			'sort_order' => $this->config->get('payment_flow_sort_order')
		);
        return $method_data;
    }
}
