<?php
class ModelExtensionPaymentFlowMulticaja extends Model {
	public function getMethod($address, $total) {
        $this->load->language('extension/payment/flow_multicaja');

		$method_data = array(
			'code'       => 'flow_multicaja',
			'title'      => $this->language->get('text_title'),
			'terms'      => '',
			'sort_order' => $this->config->get('payment_flow_multicaja_sort_order')
		);
        return $method_data;
    }
}
