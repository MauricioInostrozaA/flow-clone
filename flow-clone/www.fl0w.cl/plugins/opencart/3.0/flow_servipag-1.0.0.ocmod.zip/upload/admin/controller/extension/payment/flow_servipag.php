<?php
class ControllerExtensionPaymentFlowServipag extends Controller {
	private $error = array();

	public function index(){
		
		$this->load->language('extension/payment/flow_servipag');
        $this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		
		/* REQUEST */
		if ($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate()) {
			
			$this->model_setting_setting->editSetting('payment_flow_servipag', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}
		/* FIN REQUEST */

		/* MOSTRAR DATOS */
		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
		
		$data['payment_flow_servipag_apikey'] = $this->config->get('payment_flow_servipag_apikey');
		$data['payment_flow_servipag_secret'] = $this->config->get('payment_flow_servipag_secret');
		$data['payment_flow_servipag_apiurl'] = $this->config->get('payment_flow_servipag_apiurl');
		$data['payment_flow_servipag_status'] = $this->config->get('payment_flow_servipag_status');
		$data['payment_flow_servipag_payment_name'] = $this->config->get('payment_flow_servipag_payment_name');
		$data['payment_flow_servipag_sort_order'] = $this->config->get('payment_flow_servipag_sort_order');
		$data['payment_flow_servipag_geo_zone_id'] = $this->config->get('payment_flow_servipag_geo_zone_id');
		$data['payment_flow_servipag_approved_status_id'] = $this->config->get('payment_flow_servipag_approved_status_id');
		$data['payment_flow_servipag_failed_status_id'] = $this->config->get('payment_flow_servipag_failed_status_id');
		
		$data['payment_flow_servipag_urlreturn'] = $this->config->get('payment_flow_servipag_urlreturn');
		$data['is_testing'] = ($this->config->get('payment_flow_servipag_apiurl')) == 'TEST' ? true: false;
		/* FIN MOSTRAR DATOS */

		/* ERROR */
		if(isset($this->error['apikey'])){
			$data['error_apikey'] = $this->error['apikey'];
		}else{
			$data['error_apikey'] = '';
		}

		if(isset($this->error['secret'])){
			$data['error_secret'] = $this->error['secret'];
		}else{
			$data['error_secret'] = '';
		}

		if(isset($this->error['apiurl'])){
			$data['error_apiurl'] = $this->error['apiurl'];
		}else{
			$data['error_apiurl'] = '';
		}
		/* FIN ERROR */

		$data['action'] = $this->url->link('extension/payment/flow_servipag', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
	
		$this->response->setOutput($this->load->view('extension/payment/flow_servipag', $data));
	}

	private function validate() {
		
		if (!$this->user->hasPermission('modify', 'extension/payment/flow_servipag')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if(!$this->request->post['payment_flow_servipag_apikey']){
			$this->error['apikey'] = $this->language->get('error_apikey');
		}

		if(!$this->request->post['payment_flow_servipag_secret']){
			$this->error['secret'] = $this->language->get('error_secret');
		}

		if(!$this->request->post['payment_flow_servipag_apiurl']){
			$this->error['apiurl'] = $this->language->get('error_apiurl');
		}
		return !$this->error;
	}
}
