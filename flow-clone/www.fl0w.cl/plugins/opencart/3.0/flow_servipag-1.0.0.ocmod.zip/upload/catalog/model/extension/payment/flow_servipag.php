<?php
class ModelExtensionPaymentFlowServipag extends Model {
	public function getMethod($address, $total) {
        $this->load->language('extension/payment/flow_servipag');

		$method_data = array(
			'code'       => 'flow_servipag',
			'title'      => $this->language->get('text_title'),
			'terms'      => '',
			'sort_order' => $this->config->get('payment_flow_servipag_sort_order')
		);
        return $method_data;
    }
}
