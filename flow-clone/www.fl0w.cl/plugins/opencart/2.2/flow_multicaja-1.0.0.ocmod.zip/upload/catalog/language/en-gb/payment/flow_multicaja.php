<?php
// Text
$_['text_title'] = 'Flow Multicaja';
$_['flow_page_title'] = 'Flow Multicaja';
$_['flow_generic_error_message'] = 'There has been an unexpected error. Please try again.';
$_['flow_custom_error_breadcrumb'] = 'Error';
$_['continue'] = 'Continue';