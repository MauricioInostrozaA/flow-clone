<?php
class ModelPaymentFlowMulticaja extends Model {
    public function getMethod($address, $total) {
        $this->load->language('payment/flow_multicaja');
        
        $method_data = array(
            'code'       => 'flow_multicaja',
            'terms'      => '',
            'title'      => $this->language->get('text_title'),
            'sort_order' => $this->config->get('flow_multicaja_sort_order')
        );
        
        return $method_data;
    }
}
