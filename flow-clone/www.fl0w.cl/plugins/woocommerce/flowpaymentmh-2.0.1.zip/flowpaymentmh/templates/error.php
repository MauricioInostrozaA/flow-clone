<p><?php echo __('Ha ocurrido un error inesperado. Por favor, intentelo nuevamente.') ?></p>
<div>
    <a href="<?php echo $url_return ?>">Return</a>
</div>