<p><?php echo __('Su cup&oacute;n ha sido generado exitosamente.') ?></p>
<div>
    <a href="<?php echo $url_return ?>">Volver al sitio</a>
</div>