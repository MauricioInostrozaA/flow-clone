<?php
namespace FlowApi\Onepay;
 
class Config {
	 
	const ENDPOINTS = array(
		'TEST'	=>	'https://sandbox.flow.cl/api',
		'PROD'	=>	'https://www.flow.cl/api'
	);

	const MODES = array(
		'TEST'	=>	'Plataforma sandbox flow',
		'PROD'	=>	'Plataforma producci&oacute;n flow'
	);

	const GATEWAY_NAME = 'flowop';

	const SERVICES = array(
		'payment'		=>	'payment/create',
		'paymentStatus'	=>	'payment/getStatus',
	);

	const PAYMENT_MODE = 5;

	const PAYMENT_STATUS_PAID = 2;
	const PAYMENT_STATUS_REJECTED = 3;
}
