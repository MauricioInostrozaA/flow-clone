<?php

use WHMCS\ClientArea;

define('CLIENTAREA', true);

require  '../../../init.php';

$ca = new ClientArea();

$ca->setPageTitle('Unexpected error');

$ca->addToBreadCrumb('index.php', Lang::trans('globalsystemname'));
$ca->addToBreadCrumb('mypage.php', 'Unexpected error');

$ca->setTemplate('flowwp_error');

$ca->output();