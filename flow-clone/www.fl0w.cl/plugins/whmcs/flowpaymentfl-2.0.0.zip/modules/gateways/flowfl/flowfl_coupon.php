<?php

use WHMCS\ClientArea;

define('CLIENTAREA', true);

require  '../../../init.php';

$ca = new ClientArea();

$ca->setPageTitle('Coupon generated');

$ca->addToBreadCrumb('index.php', Lang::trans('globalsystemname'));
$ca->addToBreadCrumb('mypage.php', 'Coupon generated');

$ca->setTemplate('flowfl_coupon');

$ca->output();