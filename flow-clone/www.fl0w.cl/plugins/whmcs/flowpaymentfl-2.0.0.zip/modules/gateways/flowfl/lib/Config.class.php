<?php
namespace FlowApi\Flow;
 
class Config {
	 
	const ENDPOINTS = array(
		'TEST'	=>	'https://sandbox.flow.cl/api',
		'PROD'	=>	'https://www.flow.cl/api'
	);

	const MODES = array(
		'TEST'	=>	'Plataforma sandbox flow',
		'PROD'	=>	'Plataforma producci&oacute;n flow'
	);

	const GATEWAY_NAME = 'flowfl';

	const SERVICES = array(
		'payment'		=>	'payment/create',
		'paymentStatus'	=>	'payment/getStatus',
	);

	const PAYMENT_MODE = 9;

	const PAYMENT_STATUS_PAID = 2;
	const PAYMENT_STATUS_REJECTED = 3;
}
