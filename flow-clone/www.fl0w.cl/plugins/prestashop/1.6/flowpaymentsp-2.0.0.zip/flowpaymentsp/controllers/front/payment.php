<?php

require_once(_PS_MODULE_DIR_."flowpaymentsp/lib/flowapisp.php");

class FlowPaymentSPPaymentModuleFrontController extends ModuleFrontController{

    public function __construct(){
        parent::__construct();
        $this->display_column_left = false;
    }

    public function initContent(){

        parent::initContent();
        
        $cart = $this->context->cart;
        $rechargePercentage = Configuration::get('FLOW_SP_RECHARGE');
        $amount = (int) $cart->getOrderTotal(true, Cart::BOTH);
        $recharge = round(($amount * $rechargePercentage) / 100.00);
        $finalAmount = $amount + $recharge;
        $action = $this->context->link->getModuleLink('flowpaymentsp', 'paymentcreate', array());

        $this->context->smarty->assign(
            array(
                'action'                =>  $action,
                'amount'                =>  $amount,
                'recharge'              =>  $recharge,
                'recharge_percentage'   =>  $rechargePercentage,
                'finalAmount'           =>  $finalAmount
            )
        );
        $this->setTemplate('payment_confirmation.tpl');

        /*try{

            $cart = $this->context->cart;
            $cartId = $cart->id;
            $customer = $this->context->customer;

            $commerceOrder = $cartId;
            $subject = html_entity_decode('Orden #'.$commerceOrder.' de '.Configuration::get('PS_SHOP_NAME'), ENT_QUOTES, 'UTF-8');
            $amount = $cart->getOrderTotal(true, Cart::BOTH);
            $additionalAmount = round(($amount * Configuration::get('recharge'))/100.0);
            $finalAmount = (int) ($amount + $additionalAmount);
            $userEmail = $customer->email;
            $urlConfirmation = $this->context->link->getModuleLink('mypaymentmodule', 'confirmation', array());
            $urlReturn = $this->context->link->getModuleLink('mypaymentmodule', 'return', array());

            $params = array(
                "commerceOrder" => $commerceOrder, 
                "subject" => $subject, 
                "currency" => "CLP", 
                "amount" => $finalAmount, 
                "email" => $userEmail, 
                "paymentMethod" => $this->getPaymentMedium($this->paymentMediumName), 
                "urlConfirmation" => $urlConfirmation, 
                "urlReturn" => $urlReturn,
            );

            $apiKey = Configuration::get('api_key');
            $secretKey = Configuration::get('secret_key');
            $mode = Configuration::get('mode');
            $endpoint = $mode == 'TEST' ? 'https://flow.tuxpan.com/api' : 'https://flow.cl/api';

            Logger::addLog('Calling Flow Service: '.$service. 'With params: '.json_encode($params));
            $flowApi = new FlowApiSP($apiKey, $secretKey, $endpoint);
            $service = 'payment/create';
            $method = 'POST';

            $response = $flowApi->send($service, $params, $method);
            $urlToRedirect = $response['url'].'?token='.$response['token'];

            header('Location: '.$urlToRedirect);
            die();
        }catch(\Exception $e){
            Logger::addLog('There\'s been an unexpected error: '.$e->getCode(). ' - '.$e->getMessage());
            throw $e;
        }*/
        
    }

}