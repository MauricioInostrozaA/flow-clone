<?php

include_once(dirname(__FILE__).'/../../../config/config.inc.php');
include_once(__DIR__."/FlowApiFlow.class.php");

class PrestaFlowFlow
{
    public static function getFlowApiFlow()
    {
        $platform = Configuration::get('FLOW_PLATFORM');
        $isTestPlatform = !$platform || $platform == 'test';
        $urlApi = $isTestPlatform ? "https://sandbox.flow.cl/api" : "https://www.flow.cl/api";

        $apiKey = Configuration::get('FLOW_APIKEY');
        $secretKey = Configuration::get('FLOW_PRIVATEKEY');
        
        return new FlowApiFlow($apiKey, $secretKey, $urlApi);
    }
}