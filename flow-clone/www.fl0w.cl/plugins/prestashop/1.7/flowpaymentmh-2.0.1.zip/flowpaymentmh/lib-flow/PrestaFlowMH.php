<?php

include_once(dirname(__FILE__).'/../../../config/config.inc.php');
include_once(__DIR__."/FlowApiMH.class.php");

class PrestaFlowMH
{
    public static function getFlowApiMH()
    {
        $platform = Configuration::get('FLOW_MH_PLATFORM');
        $isTestPlatform = !$platform || $platform == 'test';
        $urlApi = $isTestPlatform ? "https://sandbox.flow.cl/api" : "https://www.flow.cl/api";

        $apiKey = Configuration::get('FLOW_MH_APIKEY');
        $secretKey = Configuration::get('FLOW_MH_PRIVATEKEY');
        
        return new FlowApiMH($apiKey, $secretKey, $urlApi);
    }
}