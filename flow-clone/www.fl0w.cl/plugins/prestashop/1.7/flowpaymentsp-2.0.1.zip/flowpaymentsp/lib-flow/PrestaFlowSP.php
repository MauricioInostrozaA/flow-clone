<?php

include_once(dirname(__FILE__).'/../../../config/config.inc.php');
include_once(__DIR__."/FlowApiSP.class.php");

class PrestaFlowSP
{
    public static function getFlowApiSP()
    {
        $platform = Configuration::get('FLOW_SP_PLATFORM');
        $isTestPlatform = !$platform || $platform == 'test';
        $urlApi = $isTestPlatform ? "https://sandbox.flow.cl/api" : "https://www.flow.cl/api";

        $apiKey = Configuration::get('FLOW_SP_APIKEY');
        $secretKey = Configuration::get('FLOW_SP_PRIVATEKEY');
        
        return new FlowApiSP($apiKey, $secretKey, $urlApi);
    }
}