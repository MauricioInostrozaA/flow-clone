<?php

include_once(dirname(__FILE__).'/../../../config/config.inc.php');
include_once(__DIR__."/FlowApiMC.class.php");

class PrestaFlowMC
{
    public static function getFlowApiMC()
    {
        $platform = Configuration::get('FLOW_MC_PLATFORM');
        $isTestPlatform = !$platform || $platform == 'test';
        $urlApi = $isTestPlatform ? "https://sandbox.flow.cl/api" : "https://www.flow.cl/api";

        $apiKey = Configuration::get('FLOW_MC_APIKEY');
        $secretKey = Configuration::get('FLOW_MC_PRIVATEKEY');
        
        return new FlowApiMC($apiKey, $secretKey, $urlApi);
    }
}