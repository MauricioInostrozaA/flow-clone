<!DOCTYPE html>
<html lang="es" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">

<head>
	        
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TTPSNQC');</script>
<!-- End Google Tag Manager -->    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Flow - Plataforma de pagos online - Chile</title>
    <meta name="description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito">
    <meta name="keywords" content="plataforma de pagos, pagos online, pagar, cobrar, pagos en linea, pagos electronicos, ecommerce, tarjetas, credito, debito, redcompra, prepago, webpay, tarjetas de credito, visa, mastercard, magna, american express, sistema de pagos, recaudar, chile, cuotas, ventas online, transbank">
    <meta name="author" content="Flow">
    <meta property="og:title" content="Flow - Plataforma de pagos online - Chile"/>
    <meta property="og:description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito"/>
    <meta property="og:site_name" content="Flow"/>
    <meta property="og:type" content="website"/>
    <meta property="og:image" content="https://www.flow.cl/img/6.png"/>
    <meta property="og:image:width" content="400"/>
    <meta property="og:image:height" content="211"/>
    <meta property="og:image:alt" content="Flow Plataforma de pagos online"/>
    <meta property="og:url" content="https://www.flow.cl/terminos.php"/>
    <link rel="canonical" href="https://www.flow.cl/terminos.php" />
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/img/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/img/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
    <link rel="manifest" href="/img/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="/css/bootstrap.3.3.7.min.css">
    <link rel="stylesheet" href="/css/forms.css">
    <link rel="stylesheet" href="/css/flow.css">
    <link rel="stylesheet" href="/css/menu.css">
    <link rel="stylesheet" href="/css/footer.css?v=20191203">
    <link rel="stylesheet" href="/css/font-awesome.4.7.0.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato|Montserrat">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->
       <!-- CSS Propio -->
    <link rel="stylesheet" href="/css/colores.css">
    <link rel="stylesheet" href="/css/interior.css">
    <link rel="stylesheet" type="text/css" href="/js/fancybox/dist/jquery.fancybox.min.css">
	<style>
		#header img {
			width: 80%;
		}
		.descargar {
			padding-top: 4px;
			text-align: right;
		}
		li.tyc {
			padding-top: 10px;
		}
		
	</style>
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTPSNQC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><!-- NAVBAR -->
<div id="mainNav" class="navbar yamm navbar-default navbar-fixed-top">
    <div class="container menuSuperior">
        <div class="navbar-header">
            <button type="button" data-toggle="collapse" data-target="#navbar-collapse-2" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a href="index.php" class="navbar-brand"><img src="images/header/logo-flow.svg"></a>
        </div>
        <div id="navbar-collapse-2" class="navbar-collapse collapse collapseHeader">
            <ul class="nav navbar-nav pull-left">
                <li><a href="info.php" class="menu">Conócenos</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu">Recibe pagos<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <!-- Content container to add padding -->
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="cobra-email.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/cobro-email.svg"> Cobra por email</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/carro-compra.svg">En tu carro de compras</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/mall.svg"> En tu propia tienda gratis</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="vende-presencialmente.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/venta-presencial.svg"> Vende presencialmente</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="redes-sociales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/redes-sociales.svg"> En redes sociales</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="soluciones-empresariales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/soluciones-empresariales.svg"> Soluciones empresariales </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="suscripciones.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/forma-recurrente.svg"> Suscripciones</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="web-sistema.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/web-sistema.svg"> En tu web o sistema computacional </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="reembolsos.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/reembolso.svg"> Reembolsos</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu" aria-expanded="false">Información técnica <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg">Integrar plugins de e-commerce</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="/docs/api.html" target="_blank">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica.svg">Documentación API Rest</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg"> Integrar Sumar.cl a tu sitio web</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="/faq.php"class="menu">Ayuda</a>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="http://comunicaciones-flow.cl/blog" target = "_blank" class="menu">Blog</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/register.php" class="menu">Regístrate</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/login.php" class="menu">Ingresa</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="visible-lg"><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default botonMenu">Regístrate</a>
                </li>
                <li class="visible-lg"><a href="app/web/login.php" class="btn btn-default btn-lg btn-flow-inv botonMenu">Ingresa</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- !NAVBAR -->	<div id="secondNavbar" class="navbar navbar-fixed-top second-navbar visible-lg">
		<div class="container">
			<div class="navbar-header pull-left second-nav">
				<ul class="nav navbar-nav">
					<li class="tituloSecond">Términos y Condiciones</li>
				</ul>
			</div>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="/app/services/tyc/get_tyc_pdf.php?id=1.2">Descargar</a></li>
				<li class="divider-vertical"></li>
				<li> <a href="javascript: history.go(-1)"><i class="fa fa-arrow-left" aria-hidden="true"></i> Volver</a> </li>
			</ul>
		</div>
	</div>
	<div class="container nopadding-movil">
		<div class="hidden-lg descargar">
			<a href="/app/services/tyc/get_tyc_pdf.php?id=1.2">
				<button class="btn" type="button">Descargar</button>
			</a>
		</div>
		<div class="seccion fondo-claro" align="justify">
			<h2>Términos y Condiciones Versión: 1.2</h2>
			<h4>Vigentes a partir del Miércoles 26 de Febrero de 2020</h4>
			
			<h3>Secciones:</h3>
<ul>
	<li><a href="#a1">1. Registro de Cuentas</a></li>
	<li><a href="#a2">2. Cuenta de Flow</a></li>
	<li><a href="#a3">3. Mandato Gestión de Pagos y Cobros</a></li>
	<li><a href="#a4">4. Entrega, acreditación y retiro de fondos</a></li>
	<li><a href="#a5">5. Condiciones Generales de Contratación</a></li>
	<li><a href="#a6">6. Productos que permiten pagar en cuotas</a></li>
	<li><a href="#a7">7. Servicios de reembolsos</a></li>
</ul>
<p>
	Importante: Cualquier persona que no acepte estos Términos y Condiciones, los cuales tienen un carácter obligatorio y vinculante, deberá abstenerse de utilizar la plataforma.
</p>
<h3 id="a1">1. Registro de Cuentas:</h3>
<p>
	Todo usuario que desee utilizar los servicios de FLOW debe registrarse en el Formulario de Registro 
	de USUARIO y aceptar estas Condiciones Generales. Para registrarse es obligatorio completar la información 
	del registro con datos exactos, precisos y verdaderos ("Datos Personales"). 
	El USUARIO asume el compromiso de mantener actualizados los Datos Personales. 
	FLOW no se responsabiliza por la veracidad de los Datos Personales provistos por el Usuario. 
	Los Usuarios garantizan y responden, en cualquier caso, de la veracidad, exactitud, integridad, 
	vigencia y autenticidad de los Datos Personales ingresados. 
	Toda la información y los Datos Personales ingresados por el Usuario tienen carácter de declaración jurada.
</p>
<p>
	FLOW se reserva el derecho de solicitar comprobantes y/o información adicional a efectos de corroborar o ampliar
	 la información entregada por el USUARIO en materia de Datos Personales, así como de suspender temporal 
	 o definitivamente a aquellas Cuentas de Usuarios cuyos datos no hayan podido ser confirmados o que no haya 
	 sido provista la información adicional solicitada a estos por parte de FLOW.
</p>
<p>
	FLOW se reserva el derecho de rechazar una solicitud de registro o de cancelar o suspender, temporal o 
	definitivamente una cuenta, en caso de detectar incongruencias o inconsistencias en la información 
	provista por un Usuario o en caso de detectar actividades sospechosas en los términos del punto 
	5. “Condiciones Generales de Contratación”, letra b) “Declaraciones del Usuario. Usos Prohibidos” de este 
	documento, sin que tal decisión genere para el Usuario derechos de indemnización o resarcimiento.
</p>
<h3 id="a2">2. Cuenta de Flow:</h3>
<p>
	Al registrarse en FLOW, el Usuario creará una cuenta (en adelante, la "Cuenta Flow" o "Cuenta"). 
	La Cuenta FLOW permitirá al Usuario realizar pagos, recibir dinero de terceros o solicitar dinero a terceros.
</p>
<p>
	El Usuario accederá a su Cuenta FLOW mediante el ingreso de su dirección de e-mail y clave de seguridad 
	personal elegida ("Clave de Ingreso") al sistema informático que provee Flow a través de la plataforma 
	dispuesta para que los Usuarios puedan ver el historial de sus transacciones, realizar pagos, recibir dinero 
	y otras transacciones (“LA PLATAFORMA”). El Usuario se obliga a mantener la confidencialidad de todas sus 
	Claves. En virtud de ello, el Usuario será el único y exclusivo responsable por todas las operaciones 
	efectuadas en su Cuenta. El Usuario se compromete a notificar a FLOW en forma inmediata y por medio idóneo 
	y fehaciente, de cualquier uso no autorizado de su Cuenta, así como del ingreso o de intentos de ingreso por
	terceros no autorizados a la misma. FLOW se reserva el derecho de implementar mecanismos adicionales de 
	verificación, los que serán comunicados al Usuario cuando estén disponibles.  La activación y uso de estos 
	mecanismos puede ser exigido por FLOW de forma obligatoria en un plazo que será comunicado desde que los controles 
	adicionales estén disponibles.
</p>
<h3 id="a3">3. Mandato Gestión de Pagos y Cobros:</h3>
<ol type="a">
	<li class="tyc">Contrato de gestión de pagos: El Usuario, podrá emitir por medio de LA PLATAFORMA una Solicitud de Pago 
		o una Solicitud de Cobro y Recaudación, en adelante “Orden Flow” u “Orden”. La Orden incluirá las 
		instrucciones para que FLOW realice la gestión de pago o cobro en su nombre.
	</li>
	<li class="tyc">
		Mandato Irrevocable: La Orden es un mandato irrevocable que otorga el Usuario a favor de FLOW para disponer 
		en su nombre Fondos de su Cuenta Flow y transferir los Fondos a un destinatario mediante su acreditación 
		en una Cuenta FLOW designada de acuerdo con sus instrucciones. Asimismo, el mandato irrevocable implica 
		una autorización del Usuario a favor de FLOW para recibir, cobrar y acreditar en su Cuenta FLOW los Fondos 
		de acuerdo con sus instrucciones. FLOW mantendrá los Fondos del Usuario en su Cuenta en las condiciones 
		y plazos establecidos en estas Condiciones Generales y/u otras condiciones especiales o particulares que 
		se establezcan para cada producto o servicio de FLOW.
	</li>
	<li class="tyc">
		Celebración de la Orden. La Orden se celebrará por medio del envío que realice el Usuario a través de 
		LA PLATAFORMA, donde se detallarán las instrucciones respecto a los Fondos. FLOW se reserva el derecho 
		de no procesar aquellas Ordenes que estén incompletas o en las cuales haya discrepancias entre los datos 
		provistos por los Usuarios y los datos ingresados efectivamente a FLOW. El Usuario es el exclusivo 
		responsable por las instrucciones contenidas en las Ordenes y sus consecuencias. FLOW no verificará la 
		causa u obligación que originó la Orden, ni las demás circunstancias relativas a las instrucciones que 
		la componen. Las instrucciones introducidas en una Orden sólo podrán efectuarse a través de la Plataforma 
		y ninguna instrucción cursada será procesada ni reputada válida, por otros medios ajenos a la Plataforma.
	</li>
	<li class="tyc">
		Responsabilidad de FLOW por la Orden. FLOW no será responsable ni verificará las causas, importe o cualquier 
		otra circunstancia relativa a dicha Orden, así como respecto de la existencia, calidad, cantidad, 
		funcionamiento, estado, integridad o legitimidad de los bienes o servicios ofrecidos, adquiridos o 
		enajenados por los Usuarios. Flow tampoco será responsable por órdenes, instrucciones, y/o pagos 
		equivocados o incompletos causados por el envío de información errónea en las instrucciones que 
		conforman la Orden enviadas por el Usuario o de información errónea que ingrese el Pagador en el proceso 
		de pago.<br><br>
		La Plataforma sólo facilita la recaudación de los pagos generados en una transacción anterior entre el Usuario 
		y el Pagador.<br><br>
		En caso de que uno o más Usuarios o algún tercero inicien cualquier tipo de reclamo o acciones legales contra 
		otro u otros Usuarios, todos y cada uno de los Usuarios involucrados en dichos reclamos o acciones eximen 
		de toda responsabilidad a FLOW y a sus directores, gerentes, empleados, agentes, operarios, representantes 
		y apoderados y renuncian a ejercer las acciones legales de cualquier naturaleza que les pudieran corresponder. 
	</li>
</ol>
<h3 id="a4">4. Entrega, acreditación y retiro de fondos:</h3>
<ol type="a">
	<li class="tyc">
		Entrega de Fondos. El Usuario podrá ingresar fondos en su cuenta FLOW. El Usuario entregará los Fondos a 
		FLOW mediante la utilización de cualquiera de los medios disponibles a tal fin y autorizados por FLOW.
	</li>
	<li class="tyc">
		Acreditación de Fondos. La acreditación de los Fondos en la Cuenta FLOW del Usuario se realizará una vez 
		que FLOW reciba la autorización del medio de pago utilizado en la transacción. Este plazo podría ser mayor 
		si el Usuario debiera cumplir con algún proceso de verificación requerido por FLOW para poder procesar la 
		Orden. FLOW ingresará en la Cuenta del Usuario o en las Cuentas de los Usuarios, de acuerdo con las 
		instrucciones enviada en la Orden, los montos correspondientes descontado el costo del servicio y los 
		impuestos correspondientes, que efectivamente haya sido acreditado por el medio de pago utilizado.<br><br>
		Por razones de seguridad, los Fondos que se acrediten en la Cuenta del Usuario y/o que estén en proceso de 
		ser acreditados (sin importar el medio de pago por el que se hubiera efectuado la transacción) podrán 
		permanecer no disponibles cuando, a exclusivo criterio de FLOW, existan sospechas de: (i) actos contrarios 
		a la ley, (ii) operaciones o transacciones cuya naturaleza, cantidad o frecuencia puedan ser fraudulentas, 
		como por ejemplo  excesivos pedidos de devoluciones y/o contracargos, (iii) y en general, cualquier otro acto 
		contrario a los presentes Términos y Condiciones Generales de Uso y/o sospechas de violación de preceptos 
		legales por los cuales FLOW deba responder.
	</li>
	<li class="tyc">
		Retiro de los Fondos. FLOW transferirá los montos disponibles a la cuenta bancaria indicada por el Usuario en 
		la Cuenta FLOW, en el plazo acordado según las Tarifas seleccionadas en la Cuenta Flow o en el contrato 
		físico firmado. FLOW emitirá una liquidación de fondos, en adelante LIQUIDACIÓN cada vez que transfiera los 
		fondos de la Cuenta FLOW.<br><br>
		FLOW realizará los esfuerzos razonables para asegurar el cumplimiento de los plazos antes indicados. No 
		obstante, el Usuario entiende que, por determinados factores, en su mayoría externos a FLOW, se pueden 
		originar retrasos, motivo por el cual el Usuario exime a FLOW de toda responsabilidad por los inconvenientes 
		o perjuicios derivados.
	</li>
	<li class="tyc">
		Contracargos, reversiones, desconocimiento o anulación de cargos efectuados, en adelante “Contracargos”. 
		Consisten en la impugnación por parte del Pagador, entendiendo por tal, a quien compra los bienes o utiliza 
		los servicios prestados por el Usuario, o de la empresa procesadora de pagos a nombre del Pagador, de cargos 
		efectuados por cualquier medio de pago utilizado. Si el Pagador, o la empresa procesadora del medio de pago 
		realizara Contracargos sobre los importes involucrados en la operación, Flow notificará vía correo 
		electrónico al Usuario y luego procederá a descontar dichos importes de los fondos pendientes de transferir 
		al Usuario. En virtud de ello, el Usuario autoriza expresamente a Flow a descontar Fondos de la siguiente 
		liquidación y así sucesivamente hasta la completa recuperación de los dineros para cubrir los Contracargos, 
		y si no dispusiera de fondos suficientes, a debitarlos de cualquier otro ingreso futuro de Fondos a su 
		cuenta, o el Usuario se compromete a pagarlos dentro de los diez (10) días siguientes al descuento de los 
		Fondos. Se establece que, a efectos de impugnar los Contracargos, será importante cualquier prueba que el 
		Usuario pudiera aportar a FLOW en su defensa, pero ello no implicará que los Fondos sean restituidos 
		nuevamente ni que FLOW se comprometa a impugnar los Contracargos incluso si el Usuario ha proporcionado 
		pruebas. En caso de Contracargos, El Usuario deberá responder ante FLOW por el importe involucrado más 
		cualquier otro costo o gasto aplicable. FLOW podrá iniciar las medidas judiciales o extrajudiciales que 
		estime pertinentes a los efectos de obtener el pago de dichos fondos. El Usuario se compromete a conservar 
		la documentación respaldatoria de la operación de venta del bien, producto o servicio efectuado a través de 
		FLOW, inclusive aquella que compruebe el envío o entrega del bien o producto en cuestión, por el plazo 
		mínimo de un año contado a partir de la recepción de los Fondos.<br><br>
		Las controversias entre el Usuario y el Pagador que dieron motivos a los Contracargos deberán ser resueltas 
		directamente entre esas partes, sin intervención ni responsabilidad alguna de FLOW.
	</li>
	<li class="tyc">
		Responsabilidad por los Fondos. Se establece que FLOW mantendrá los Fondos de las Cuentas FLOW en una o más 
		cuentas bancarias a su nombre ("Cuentas Recaudadoras") y utilizará diversos agentes de transferencia de 
		dinero. FLOW no será responsable en ningún caso por la insolvencia, por situaciones políticas o económicas 
		que pudieran presentarse en el país o cualquier otra situación que pudieran afectar al Banco, entidad 
		financiera o agente utilizado para la transferencia de los Fondos o cualquier cambio legal o regulatorio que 
		afecte la cuenta en la cual los Fondos sean depositados por FLOW. En estos casos, los Usuarios no podrán 
		imputarle responsabilidad alguna a FLOW, sus filiales o subsidiarias, empresas controlantes y/o controladas, 
		ni exigir el reintegro del dinero o pago por lucro cesante, en virtud de perjuicios resultantes de este tipo 
		de situaciones ni por órdenes de pago no procesadas por el sistema o rechazadas, cuentas suspendidas o 
		canceladas.
	</li>
</ol>
<h3 id="a5">5. Condiciones Generales de Contratación:</h3>
<ol type="a">
	<li class="tyc">
		Capacidad. Sólo podrán ser Usuarios, y por tanto, celebrar una Orden las personan que tengan capacidad legal 
		para contratar y estén debidamente registrados en FLOW. No podrán ser Usuarios menores de edad, personas que 
		no tengan capacidad para contratar o aquellos Usuarios que hayan sido suspendidos o inhabilitados del sistema 
		de FLOW, temporal o definitivamente.
	</li>
	<li class="tyc">
		Declaraciones del Usuario. Usos Prohibidos. El Usuario manifiesta que el objeto por el cual se celebra la 
		Orden no infringe ninguna ley aplicable, ni es por un servicio, venta o transmisión que está prohibida por la 
		ley o por estos Términos y Condiciones Generales, tales como y sin limitarse a: (i) juegos de azar, apuestas, 
		prohibidas por la legislación local.; (ii) tráfico de armas, de personas, de animales, etc.; (iii) lavado de 
		dinero y/o terrorismo; (iv) prostitución o pedofilia; y/o (v) cualquier tipo de actividad que pueda ser 
		considerada fraudulenta o ilegal o sospechosa de serlo o que sea considerada por Flow como contraria a la 
		moral y las buenas costumbres.<br><br>
		El Usuario no utilizará la Plataforma para transmitir material que constituya un delito o bien que pueda dar 
		lugar, directa o indirectamente a responsabilidades civiles o que infrinjan estos Términos y Condiciones 
		Generales.<br><br>
		Si FLOW considera que hay una sospecha o indicio de la utilización de la Plataforma para alguna actividad 
		prohibida por la ley o estos Términos y Condiciones Generales, podrá rechazar, cancelar o suspender una 
		Orden, y/o bloquear temporalmente el acceso a un Usuario y/o la utilización o disponibilidad de 
		funcionalidades y/o cancelar definitivamente un Registro de Usuario En tal caso, el Usuario responderá por 
		los daños y perjuicios que pueda haber ocasionado a FLOW sus controlantes, controladas, filiales o 
		subsidiarias, funcionarios, empleados, directores, agentes, y/o empleados, a cuyos efectos FLOW se reserva 
		el derecho de iniciar las acciones judiciales o extrajudiciales que estime pertinentes.<br><br>
		El Usuario será exclusiva e ilimitadamente responsable por los perjuicios que su conducta pueda causar a FLOW 
		o a los restantes Usuarios de la Plataforma.
	</li>
	<li class="tyc">
		Flow no es entidad financiera. Se deja expresamente aclarado que FLOW no es una entidad financiera ni presta 
		al Usuario ningún servicio bancario o cambiario, sólo brinda un servicio de pago o recaudación por orden de 
		los Usuarios Mandantes según las condiciones establecidas en los Términos y Condiciones del servicio que da 
		cuenta este instrumento.
	</li>
	<li class="tyc">
		Tarifas por Servicios de Flow. El Usuario acepta pagar una comisión por los servicios de recaudación, según 
		las Tarifas que contrató en su Cuenta Flow o las Tarifas contratadas por medio de un contrato firmado, 
		facultando a FLOW en forma expresa para que deduzca, al momento de la recaudación, los dineros equivalentes 
		al servicio acordado por cada transacción comercial. Las tarifas por otros servicios de Flow, distintos al 
		de recaudación, serán adicionales y complementarios a estos y serán publicados en la página de Tarifas 
		vigentes, rigiendo la que se encuentre vigente al momento de prestar el servicio.
	</li>
	<li class="tyc">
		Modificación de Tarifas. FLOW podrá modificar en cualquier momento las Tarifas vigentes de sus Servicios. 
		FLOW notificará de los cambios al Usuario publicando una versión actualizada de Tarifas, además, enviará un 
		correo electrónico a la dirección del Usuario registrado en la Cuenta FLOW notificando del cambio realizado. 
		El Usuario podrá suscribir las nuevas tarifas en su Cuenta FLOW a partir de la notificación. Pasados 
		10 (diez) días de enviada la notificación al Usuario, FLOW se reserva el derecho de actualizar las tarifas contratadas en la cuenta 
		del Usuario por las nuevas tarifas vigentes. El Usuario deberá comunicar por e-mail si no acepta las nuevas tarifas y deberá 
		abstenerse de utilizar los servicios de FLOW, en ese caso, quedará disuelto el vínculo contractual. Vencido 
		este plazo, se considerará que el Usuario acepta las nuevas tarifas y faculta a FLOW para modificar las 
		tarifas contratados en su Cuenta FLOW por las nuevas tarifas vigentes.
	</li>
	<li class="tyc">
		Modificaciones de los Términos y Condiciones de los Servicios. FLOW podrá modificar en cualquier momento los Términos y Condiciones de sus Servicios. 
		FLOW notificará los cambios al Usuario publicando una versión actualizada de dichos Términos y Condiciones en la 
		Plataforma con expresión de la fecha de la última modificación y enviará un correo electrónico a la dirección del 
		Usuario registrada en la Cuenta FLOW informando cuales fueron los cambios realizados, además de enviar un hipervínculo 
		que permita al Usuario acceder y descargar los nuevos términos y condiciones. Dentro de los 10 (diez) días siguientes 
		a la publicación de las modificaciones introducidas, el Usuario deberá comunicar por e-mail si no acepta las mismas 
		y deberá abstenerse de utilizar los servicios de FLOW; en ese caso quedará disuelto el vínculo contractual. 
		Vencido este plazo, se considerará que el Usuario acepta los nuevos términos y el contrato continuará vinculando a ambas partes. 
		Los Términos y Condiciones de los Servicios modificados serán aplicables a toda Orden que se celebre con posterioridad a la 
		notificación al Usuario.
	</li>
	<li class="tyc">
		Terminación del Contrato. FLOW y el Usuario del Servicio podrán en cualquier oportunidad de vigencia del 
		presente contrato terminarlo sin expresión de causa alguna, lo que implicará el cierre de la Cuenta del 
		Usuario. A los efectos de ejercer esta facultad, es necesario que la 
		parte que pretende la terminación del contrato no adeude a la otra ni a terceros involucrados en las 
		operaciones el cumplimiento de alguna obligación.<br><br>
		Asimismo, FLOW podrá, en caso de incumplimiento del Usuario a las condiciones del presente contrato o a la 
		legislación aplicable en la materia, dar por terminada la prestación del Servicio sin ningún tipo de aviso 
		previo, reservándose el derecho de reclamar los daños y perjuicios que tal incumplimiento le haya causado.
	</li>
	<li class="tyc">
		Limitación de Responsabilidad por el Servicio y/o la Plataforma. FLOW no garantiza el acceso y uso continuado 
		o ininterrumpido de La Plataforma ni sus servicios. El sistema puede eventualmente no estar disponible debido 
		a dificultades técnicas o fallas de Internet en los links o Herramientas de Venta o por cualquier otra 
		circunstancia ajena a FLOW. Los Usuarios NO podrán imputarle responsabilidad alguna a FLOW, ni exigir 
		resarcimiento alguno, en virtud de perjuicios resultantes de las mencionadas dificultades, así como por 
		cualquier otra clase de daños, incluyendo daños indirectos, especiales o consecuentes que surjan o 
		experimenten los Usuarios, incluso en el caso que dichas fallas afecten los montos que deban ser pagados o 
		acreditados. FLOW no garantiza la disponibilidad ni la continuidad operacional de los Operadores de Medios de 
		Pago. Flow puede discrecionalmente poner término al contrato con los Operadores sin que esto conlleve alguna 
		responsabilidad para Flow. El pagador utilizará los servicios que proveen los Operadores de Medios de Pago 
		que estén disponibles en la plataforma al momento de realizar el pago.
	</li>
	<li class="tyc">
		Notificaciones. Serán válidas todas las notificaciones realizadas a los Usuarios por FLOW en la dirección de 
		correo electrónico de notificación registrada por éstos.
	</li>
	<li class="tyc">
		Notificaciones de reclamo. Sin perjuicio del punto 3 letra d) Responsabilidad de FLOW por la Orden, FLOW 
		podría emitir una "Notificación de reclamo" a un determinado Usuario ante la solicitud de un Pagador producto 
		de la disconformidad asociada a la recepción de un producto o servicio adquirido. En dicho caso, FLOW 
		utilizará el siguiente protocolo, el cual es aceptado y entendido por ambos usuarios:
		<p>
			Notificación de reclamo. Flow enviará mediante correo electrónico una "Notificación de reclamo" al 
			Usuario, en la cual se indica el detalle del pago asociado al reclamo y también una descripción del 
			reclamo. En dicha “Notificación de reclamo” se solicita al Usuario lo siguiente:
		</p>
		<ol type="i">
			<li class="tyc">Contactar al cliente y dar respuesta satisfactoria a su reclamo, en un plazo máximo de 24 Hrs.</li>
			<li class="tyc">Responder a la “Notificación de reclamo” emitida por FLOW, en un plazo máximo de 24 Hrs.</li>
		</ol>
		<p>
			Notificación de reclamo sin respuesta: De no tener respuesta satisfactoria en las 24 Hrs indicadas en el 
			punto anterior, el Usuario autoriza FLOW a:
		</p>
		<ol type="i">
			<li class="tyc">
				suspender y/o cancelar la cuenta del Usuario y cualquier otra Cuenta de Usuario relacionada a ella.
			</li>
			<li class="tyc">
				entregar los datos del Usuario registrado en FLOW al Pagador: los datos de contacto del comercio y 
				los datos de la cuenta bancaria donde se le han depositado los montos pagados. Siendo el objetivo de 
				la entrega de esta información, permitir al Pagador perseguir la devolución del dinero directamente 
				del Usuario, lo que este último acepta expresamente.
			</li>
			<li class="tyc">
				Reembolsar o anular cualquier pago no transferido o cualquier pago futuro realizado a la cuenta del 
				Usuario o a cualquier otra relacionada a ella.
			</li>
		</ol>
	</li>
	<li class="tyc">
		Cambio de antecedentes de el Usuario. El Usuario deberá modificar en forma inmediata, en el sistema Flow, 
		cualquier cambio relativo a los antecedentes registrados en él y que sean necesarios para la correcta 
		ejecución del mandato. El Usuario es responsable exclusivo de informar oportunamente a Flow de cualquier 
		cambio en la forma de pago, especialmente tratándose de la cuenta bancaria en la que se debe depositar los 
		montos recaudados. En ese sentido, Flow no será responsable por los perjuicios que dicha falta de 
		actualización de la información le pudiera causar.
	</li>
	<li class="tyc">
		Controversia Usuario y Pagador. Cualquier controversia o dificultad entre el Usuario y el Pagador, 
		especialmente las relativas a la calidad, cantidad o cualquier característica del servicio y/o bien prestado 
		por el Usuario, deberá ser resuelta directamente entre esas partes, sin intervención ni responsabilidad 
		alguna de Flow.
	</li>
	<li class="tyc">
		No exclusividad. La aceptación de este instrumento no implica exclusividad ni significa, en caso alguno, que 
		las Partes se encuentren impedidas de celebrar otros contratos de similar o igual naturaleza con otras 
		personas naturales o jurídicas.
	</li>
	<li class="tyc">
		Propiedad de los fondos. El Usuario declara conocer que las sumas de dinero que Flow percibe de El Pagador y 
		paga al Usuario en razón de las operaciones descritas en este acuerdo no son de propiedad de Flow, siendo 
		éste un mero tenedor de ellas, sin perjuicio de lo concerniente a los pagos que por el uso del Sistema de 
		cobro correspondan, de conformidad a los señalado en el presente instrumento.
	</li>
	<li class="tyc">
		Modelo de prevención de delitos. El Usuario, en representación de sus trabajadores, ejecutivos principales, 
		socios o accionistas, directores y demás relacionados, declara dar, actualmente y en el futuro, cumplimiento 
		total y oportuno a las leyes, reglamentos, normas y disposiciones, legales o administrativas, relacionadas 
		con materias de lavado y blanqueo de activos, financiamiento del terrorismo, cohecho, receptación y los demás 
		delitos contemplados en la Ley número veinte mil trescientos noventa y tres. En relación a lo anterior, 
		efectúa las siguientes declaraciones, cuya veracidad, corrección e integridad se eleva a condición de 
		esencial:
		<ol type="1">
			<li class="tyc">
				Que directa o indirectamente, no han ofrecido, prometido, pagado, o entregado, y que en el futuro, no 
				ofrecerán, prometerán, pagarán, o entregarán, dinero o especies, a ningún funcionario de gobierno, 
				público o municipal; partido político, o candidato a cargo político y en general, a cualquier persona 
				que trabaje en alguna entidad gubernamental, o a cualquiera de los familiares de éstos, con el fin 
				de: i) asegurar cualquier ventaja indebida, y/o ii) influir en un acto o decisión de autoridad, con 
				el fin de obtener o mantener un negocio relacionado directa o indirectamente con el presente 
				contrato.
			</li>
			<li class="tyc">
				Que no poseen fondos, bienes o dineros que provengan, directa o indirectamente, de actividades 
				ilícitas, y tampoco afectos a alguno de los delitos contemplados en el artículo veintisiete de la Ley 
				número diecinueve mil novecientos trece, o la que la sustituya o reemplace.
			</li>
			<li class="tyc">
				Que ni ellos, ni ninguna de sus personas naturales o jurídicas relacionadas, ni ningún gerente o 
				representante legal, es terrorista o miembro de organizaciones terroristas;
			</li>
			<li class="tyc">
				Que no mantienen en su poder, transportan, compran, venden, transforman ni comercializan, de ninguna 
				forma, especies hurtadas, robadas u objetos de abigeato, de receptación o de apropiación indebida; y
			</li>
			<li class="tyc">
				Que el personal de su dependencia, así como aquellos terceros que participan bajo su control, 
				dependencia y/o a petición del mismo en actuaciones que supongan desarrollo del presente acuerdo, se 
				encuentran en debido conocimiento de la Ley N° 20.393 y están debidamente capacitados en la referida 
				ley y en el correspondiente Modelo de Prevención.
			</li>
			<li class="tyc">
				Que iguales acciones de capacitación se desarrollarán y/o exigirán respecto de todo otro nuevo 
				dependiente o tercero que en el futuro se incorpore o tenga intervención en la ejecución de las 
				actividades del Usuario.
			</li>
			<li class="tyc">
				Que, todas las declaraciones precedentes son completamente fidedignas y que no se ha omitido ningún 
				hecho relevante o no, que incida o pueda incidir en las materias descritas en la presente cláusula.
			</li>
		</ol>

	</li>
</ol>
<h3 id="a6">6. Productos que permiten pagar en cuotas:</h3>
<p>
	Flow pone a disposición del Usuario a través de su Plataforma, productos que permiten al Pagador la opción de
	realizar el pago en cuotas. 
	Debe tenerse presente que el Pagador podría tener costos asociados por cuenta del emisor de la tarjeta.
	La terminación del contrato implicará el término automático de este producto. 
</p>
<h3 id="a7">7. Servicios de reembolsos:</h3>
<p>
	Los reembolsos son un servicio adicional prestado por Flow a los Usuarios para devolver los gastos en que hubiese 
	incurrido un Pagador por la adquisición de un servicio o producto. El servicio de Reembolso constituye un 
	servicio adicional al de pago o recaudación y en ningún caso representa la anulación del servicio de pago o 
	recaudación prestado ni su costo.
</p>
<ol type="a">
	<li class="tyc">Condiciones para solicitar un reembolso</li>
	<ul>
		<li class="tyc">
			Debe estar registrado en FLOW como Usuario y su cuenta debe estar activa.
		</li>
		<li class="tyc">
			Debe disponer de fondos en la plataforma por pagos aún no transferidos a su cuenta bancaria que cubran 
			el monto solicitado a reembolsar.
		</li>
		<li class="tyc">
			El monto del reembolso no debe superar en más de un 50% el monto original pagado, en caso de que el 
			Usuario desee brindar una indemnización.
		</li>
	</ul>
	<li class="tyc">Procedimiento de Reembolso</li>
	<ul>
		<li class="tyc">
			Emitir una solicitud de Reembolso por medio de página Web de la plataforma o su API de integración.
		</li>
		<li class="tyc">
			FLOW descontará al Usuario el monto del reembolso y su cargo por servicio de la siguiente 
			liquidación de recaudación a transferir y retendrá los fondos hasta que el reembolso se materialice.
		</li>
		<li class="tyc">
			FLOW contactará vía email al Pagador para solicitarle la aceptación o rechazo del reembolso. Una 
			vez que el Pagador ha manifestado su decisión, esta información será notificada al Usuario 
			que solicitó el reembolso.
		</li>
		<li class="tyc">
			El reembolso se materializará vía transferencia de fondos a la cuenta bancaria que señale el Pagador. 
			En el caso que la transacción original fuese realizada por medio de Tarjeta de Crédito, FLOW ofrecerá, 
			como alternativa de reembolso, la anulación parcial o total del cargo efectuado en la tarjeta de crédito.
		</li>
		<li class="tyc">
			En el caso de que el Pagador rechace el reembolso, FLOW notificará vía email al Usuario de esta situación, 
			y el dinero previamente descontado en la liquidación del Usuario, será agregado a la siguiente 
			liquidación y transferido a la cuenta bancaria del Usuario.
		</li>
	</ul>
	<li class="tyc">Estados de una solicitud de Reembolso</li>
	<ul>
		<li class="tyc">
			Solicitado La Plataforma ha recibido la solicitud de Reembolso.
		</li>
		<li class="tyc">
			Aceptado El Usuario Pagador ha aceptado el reembolso.
		</li>
		<li class="tyc">
			Rechazado El Usuario Pagador ha rechazado el reembolso.
		</li>
		<li class="tyc">
			Reembolsado El reembolso se concretó.
		</li>
		<li class="tyc">
			Anulado La solicitud de reembolso ha sido anulada.
		</li>
	</ul>
	<li class="tyc">Costo de Reembolso</li>
	<p>
		El servicio de Reembolso tiene un costo por cada Reembolso efectuado, y su tarifa será la publicada en la 
		página de Tarifas vigentes al momento de efectuarse el Reembolso. Este monto será descontado de la siguiente 
		liquidación y será facturado una vez que el reembolso ha sido aceptado por el Pagador.
	</p>
</ol>		</div>
	</div>
	<!-- FOOTER -->
<div id="footer" class="footer">
    <div class="container visible-lg visible-md">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6">
                <h5>Preguntas frecuentes</h5>
                <ul class="unstyled">
                    <li><a href="faq.php#pagar">Pagar con Flow</a>
                    </li>
                    <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                    </li>
                    <li><a href="faq.php#ayuda">Ayuda técnica</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Tarifas y condiciones</h5>
                    <ul class="unstyled">
                        <li><a href="tarifas.php">Tarifas vigentes</a>
                        </li>
                        <li><a href="terminos.php">Términos &amp; condiciones</a>
                        </li>
                        <li><a href="privacidad.php">Política de privacidad</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Contacto</h5>
                    <ul class="unstyled">
                        <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                        </li>
                        <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 cajaLogos">
                <h5>En Flow recibes pagos con: </h5>
                <ul class="unstyled">
                    <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container hidden-lg hidden-md">
        <div class="panel-default" id="accordionFooter" role="tablist" aria-multiselectable="true">
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter1">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter1" aria-expanded="true" aria-controls="collapseFooter1"> <i class="more-less fa fa-chevron-down"></i> Preguntas frecuentes </a> </h4>
                </div>
                <div id="collapseFooter1" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter1">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="faq.php#pagar">Pagar con Flow</a>
                            </li>
                            <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                            </li>
                            <li><a href="faq.php#ayuda">Ayuda técnica</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter2">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter2" aria-expanded="true" aria-controls="collapseFooter2"> <i class="more-less fa fa-chevron-down"></i> Tarifas y condiciones </a> </h4>
                </div>
                <div id="collapseFooter2" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter2">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tarifas.php">Tarifas vigentes</a>
                            </li>
                            <li><a href="terminos.php">Términos &amp; condiciones</a>
                            </li>
                            <li><a href="privacidad.php">Política de privacidad</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter3">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter3" aria-expanded="true" aria-controls="collapseFooter3"> <i class="more-less fa fa-chevron-down"></i> Contacto </a> </h4>
                </div>
                <div id="collapseFooter3" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter3">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                            </li>
                            <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter4">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter4" aria-expanded="true" aria-controls="collapseFooter4"> <i class="more-less fa fa-chevron-down"></i> En Flow recibes pagos con: </a> </h4>
                </div>
                <div id="collapseFooter4" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter4">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter5">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter5" aria-expanded="true" aria-controls="collapseFooter5"> <i class="more-less fa fa-chevron-down"></i> Seguridad </a> </h4>
                </div>
                <div id="collapseFooter5" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter5">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/seguro.php#sitelock"><img alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a> </li>
                            <li class="logosMediosPagos"> <a href="/seguro.php#pci"><img alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="socialFooter" class="social-footer" align="center">
    <div class="container">
        <div class="row">
            <div class="col-md-12"> 
                <div class="hidden-xs hidden-sm pull-left"><a href="/seguro.php#sitelock"><img class="img-responsive" alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a>
                </div>
                <a href="http://www.facebook.com/flow.cl" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-facebook fa-stack-1x"></i> </span></a> <a href="https://twitter.com/@flow_chile" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-twitter fa-stack-1x"></i> </span></a> <a href="https://www.instagram.com/flowpuntocl/" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-instagram fa-stack-1x"></i> </span></a> <a href="http://vimeo.com/flowvideos" target="_blank" class="hvr-grow"> <span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-vimeo fa-stack-1x"></i> </span></a> <a href="https://www.youtube.com/channel/UCIHMLt0pJDoTX19QJWpc5dg?view_as=subscriber" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-youtube-play fa-stack-1x"></i> </span></a>
                <div class="hidden-xs hidden-sm pull-right"><a href="/seguro.php#pci"><img class="img-responsive" alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- / FOOTER --> 

<!-- Modal Contactanos -->
<div class="modal fade" id="modalContactanos" tabindex="-1" role="dialog" aria-labelledby="modalContactanosLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>Contáctanos para mayor información </h2>
                </div>
            </div>
            <div class="modal-body">
                <p> ¿Quieres obtener este servicio? Puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<!-- Modal Pronto -->
<div class="modal fade" id="modalPronto" tabindex="-1" role="dialog" aria-labelledby="modalProntoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>¡Pronto! </h2>
                </div>
            </div>
            <div class="modal-body">
                <p>Estamos trabajando en este servicio, pronto se encontrará disponible. </p>
                <p>Recuerda que puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<!-- The scroll to top feature --> 
<a href="javascript:" id="return-to-top"> <i class="fa fa-chevron-up"> </i></a>	<!-- JS -->
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.3.3.7.min.js"></script>
	<!-- JS  -->
	<script src="secciones-pagina/footer.js"></script>
</body>

</html>