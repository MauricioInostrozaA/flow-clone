<!DOCTYPE html>
<html lang="es" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">

<head>
	        
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TTPSNQC');</script>
<!-- End Google Tag Manager -->    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Flow - Plataforma de pagos online - Chile</title>
    <meta name="description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito">
    <meta name="keywords" content="plataforma de pagos, pagos online, pagar, cobrar, pagos en linea, pagos electronicos, ecommerce, tarjetas, credito, debito, redcompra, prepago, webpay, tarjetas de credito, visa, mastercard, magna, american express, sistema de pagos, recaudar, chile, cuotas, ventas online, transbank">
    <meta name="author" content="Flow">
    <meta property="og:title" content="Flow - Plataforma de pagos online - Chile"/>
    <meta property="og:description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito"/>
    <meta property="og:site_name" content="Flow"/>
    <meta property="og:type" content="website"/>
    <meta property="og:image" content="http://www.flow.cl/img/6.png"/>
    <meta property="og:image:width" content="400"/>
    <meta property="og:image:height" content="211"/>
    <meta property="og:image:alt" content="Flow Plataforma de pagos online"/>
    <meta property="og:url" content="http://www.flow.cl/boton-pago-estatico.php"/>
    <link rel="canonical" href="http://www.flow.cl/boton-pago-estatico.php" />
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/img/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/img/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
    <link rel="manifest" href="/img/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="/css/bootstrap.3.3.7.min.css">
    <link rel="stylesheet" href="/css/forms.css">
    <link rel="stylesheet" href="/css/flow.css">
    <link rel="stylesheet" href="/css/menu.css">
    <link rel="stylesheet" href="/css/footer.css?v=20191203">
    <link rel="stylesheet" href="/css/font-awesome.4.7.0.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato|Montserrat">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->
       <!-- CSS Propio -->
    <link rel="stylesheet" href="/css/colores.css">
    <link rel="stylesheet" href="/css/interior.css">
    <link rel="stylesheet" type="text/css" href="/js/fancybox/dist/jquery.fancybox.min.css">
	<style>
		#header img {
			width: 52%;
		}
	</style>
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTPSNQC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><!-- NAVBAR -->
<div id="mainNav" class="navbar yamm navbar-default navbar-fixed-top">
    <div class="container menuSuperior">
        <div class="navbar-header">
            <button type="button" data-toggle="collapse" data-target="#navbar-collapse-2" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a href="index.php" class="navbar-brand"><img src="images/header/logo-flow.svg"></a>
        </div>
        <div id="navbar-collapse-2" class="navbar-collapse collapse collapseHeader">
            <ul class="nav navbar-nav pull-left">
                <li><a href="info.php" class="menu">Conócenos</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu">Recibe pagos<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <!-- Content container to add padding -->
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="cobra-email.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/cobro-email.svg"> Cobra por email</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/carro-compra.svg">En tu carro de compras</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/mall.svg"> En tu propia tienda gratis</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="vende-presencialmente.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/venta-presencial.svg"> Vende presencialmente</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="redes-sociales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/redes-sociales.svg"> En redes sociales</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="soluciones-empresariales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/soluciones-empresariales.svg"> Soluciones empresariales </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="suscripciones.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/forma-recurrente.svg"> Suscripciones</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="web-sistema.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/web-sistema.svg"> En tu web o sistema computacional </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="reembolsos.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/reembolso.svg"> Reembolsos</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu" aria-expanded="false">Información técnica <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg">Integrar plugins de e-commerce</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="/docs/api.html" target="_blank">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica.svg">Documentación API Rest</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg"> Integrar Sumar.cl a tu sitio web</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="/faq.php"class="menu">Ayuda</a>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="http://comunicaciones-flow.cl/blog" target = "_blank" class="menu">Blog</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/register.php" class="menu">Regístrate</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/login.php" class="menu">Ingresa</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="visible-lg"><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default botonMenu">Regístrate</a>
                </li>
                <li class="visible-lg"><a href="app/web/login.php" class="btn btn-default btn-lg btn-flow-inv botonMenu">Ingresa</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- !NAVBAR -->	<div id="secondNavbar" class="navbar navbar-fixed-top second-navbar visible-lg">
		<div class="container">
			<div class="navbar-header pull-left second-nav">
				<ul class="nav navbar-nav">
					<li class="tituloSecond">Botón de pago estático</li>
				</ul>
			</div>
			<ul class="nav navbar-nav navbar-right">
				<li> <a href="javascript: history.go(-1)"><i class="fa fa-arrow-left" aria-hidden="true"></i> Volver</a> </li>
				<li class="divider-vertical"></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Accesos rápidos <i class="caret"></i></a>
					<ul class="dropdown-menu">
						<li class="sub"><a href="javascript:scroll_to_class('#target-0')">Inicio </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-1')">¿Qué es el botón de pago? </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-2')">Características </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-3')">¿Cómo crear un botón de pago? </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-4')">Publicar tu botón de pago </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-5')">Publicando en Facebook </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-6')">Tienda en Facebook </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-marketplace')">Marketplace de Facebook </a>
                        </li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-7')">¿Cómo pagan tus clientes? </a>
						</li>
					</ul>
				</li>
				<li class="divider-vertical"></li>
			</ul>
		</div>
	</div>
	<div id="header" class="header-contenido-1">
		<div class="overlay-header-contenido-celeste-o">
			<div class="container">
				<div class="row" style="margin-top: 2em;">
					<div class="col-xs-12 col-sm-7 col-lg-7">
						<h1 id="target-0" class="titulo-principal-xxl">Generar botón de pago estático</h1>
						<p class="parrafo-principal-xxl">Utiliza los botones de pago de Flow y obtén un link directo para vender tus productos y servicios mediante Webpay, Servipag y Multicaja.</p>
					</div>
					<div class="col-xs-12 col-sm-5 col-lg-5"> <img class="pull-right" src="images/soluciones/boton_pagar_flow.png"> </div>
				</div>
			</div>
		</div>
	</div>
	<div class="container nopadding-movil">
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-1"> ¿Qué es el botón de pago? </h2>
			</div>
			<p>Un botón de pago es un link de pago directo que te permite realizar cobros de forma rápida y segura.
			Puedes registrar tus productos o servicios en Flow y de forma automática te entregaremos
			un link de pago que podrás compartir en redes sociales, por correo electrónico, incorporar en tu página web y más.
			</p>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-2">Características</h2>
			</div>
			<div class="row nopadding">
				<div class="col-sm-6 nopadding">
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Fácil de usar:</strong> Genera tu botón online y luego lo podrás incrustar es una página web, en una página de Facebook, en un tweet de Twitter o en un email. </p>
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Monto fijo o variable:</strong> Puedes definir un monto fijo a pagar o puedes permitir que el monto lo ingrese el pagador.</p>
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Imagen de tu producto:</strong> Puedes agregar una imagen de tu producto para ser mostrada al momento del pago. </p>
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Botón de pago o donación:</strong> Puedes definir si tu botón se visualizará como pago o donación. </p>
				</div>
				<div class="col-sm-6 nopadding">
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Controla Stock:</strong> Permite definir el número de unidades disponibles de tu producto, así, cada vez que alguien te compre se rebajará el stock automáticamente. </p>
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Controla el vencimiento de tu oferta:</strong> Permite definir una fecha de vencimiento de tu oferta. Una vez cumplida la fecha no permitirá el pago. </p>
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Atributos personalizables:</strong> Permite definir hasta tres atributos personalizables para capturar información del pagados.</p>
					<p><i class="fa fa-check" aria-hidden="true"></i> <strong>Cambia el color de tu botón:</strong> Puedes variar el color de tu botón seleccionando alguno de los colores disponibles.</p>
				</div>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-3">¿Cómo crear un botón de pago?</h2>
			</div>
			<h3>¿No eres parte de Flow?</h3>
			<p>	
				Antes de continuar debes registrarte en Flow y seleccionar la opción <b>Deseo utilizar Flow para recibir pagos.</b>
				Si aún no estas registrado puedes hacerlo aquí:
			</p>
			<p><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default texto-boton"><img src="images/registrate.svg"> Regístrate</a>
			</p>
			<h3>Si ya eres parte de Flow</h3>
			<p>1.- Ingresa al catálogo de <strong>botones de pago</strong>, ubicado en el menú principal: </p>
			<div align="center">
				<figure> <a href="images/soluciones/boton01.jpg" data-fancybox="group" data-caption="Acceso a botones de pago"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton01.jpg" alt="Acceso a botones de pago" /> </a>
					<figcaption>Acceso a botones de pago</figcaption>
				</figure>
			</div>
			<p>2.- Crea un nuevo botón de pago: </p>
			<div align="center">
				<figure> <a href="images/soluciones/boton021.jpg" data-fancybox="group" data-caption="Vista de catálogo"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton021.jpg" alt="Vista de catálogo" /> </a>
					<figcaption>Vista de catálogo</figcaption>
				</figure>
			</div>
			<p>3.- Ingresa los datos de tu producto: </p>
			<div align="center">
				<figure> <a href="images/soluciones/boton101.jpg" data-fancybox="group" data-caption="Campos de creación de botón de pago"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton101.jpg" alt="Campos de creación de botón de pago" /> </a>
					<figcaption>Campos de creación de botón de pago</figcaption>
				</figure>
			</div>
			<h4>Descripción de los campos de tus botones</h4>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Campo</th>
							<th>Descripción</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Nombre del producto</td>
							<td>Asígnale un nombre a tu producto. </td>
						</tr>
						<tr>
							<td>Descripción</td>
							<td>Describe tu producto o servicio.</td>
						</tr>
						<tr>
							<td>Precio fijo o variable</td>
							<td>Selecciona <strong>precio fijo</strong> si tu botón de pago mostrará el precio que tú definas o <strong>precio variable</strong> si el monto a pagar lo ingresará el pagador.</td>
						</tr>
						<tr>
							<td>Monto</td>
							<td>Si seleccionaste <strong>precio fijo</strong> ingresa el precio del producto.
							El botón Calcular te permite calcular el precio en base al monto que deseas recibir descontando la comisión de Flow.
							</td>
						</tr>
						<tr>
							<td>Monto mínimo y Monto máximo</td>
							<td>Si seleccionaste precio variable ingresa un monto mínimo y un monto máximo.</td>
						</tr>
						<tr>
                            <td>Tipo de botón</td>
                            <td>Selecciona si tu botón se visualizará como pago o donación.</td>
                        </tr>
					</tbody>
				</table>
			</div>
			<h4>Más funcionalidades para el botón de pago</h4>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Campo</th>
							<th>Descripción</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Ingrese un número de productos</td>
							<td>Podrás controlar las unidades disponibles. Si no ingresas un número, Flow entenderá que tu producto es ilimitado.<br> Si ingresaste un número, cada vez que te realicen un pago disminuirá el stock.<br>
								<em>Cuando el stock llegue a cero no se permitirán pagos.</em>
							</td>
						</tr>
						<tr>
							<td>Fecha de expiración</td>
							<td>Si ingresas una fecha el botón permitirá pagos hasta que se cumpla la fecha que ingresaste.<br>
								<em>Deja en blanco la fecha de expiración si no deseas que expire.</em>
							</td>
						</tr>
						<tr>
							<td>Código externo</td>
							<td>Si manejas un código propio para tu producto ingrésalo. Cuando te paguen lo informaremos en el email de confirmación de pago.</td>
						</tr>
						<tr>
							<td>Dirección de pago exitoso</td>
							<td>Es el enlace donde direccionaremos a la persona que ha realizado el pago exitosamente.</td>
						</tr>
						<tr>
							<td>Dirección de pago fracasado</td>
							<td>Es el enlace donde direccionaremos a la persona que no ha realizado el pago exitosamente.</td>
						</tr>
					</tbody>
				</table>
			</div>
			<h4>Atributos personalizados</h4>
			<p>Flow te permite crear hasta 3 atributos personalizados por botón, que pueden ser selectores con opciones o casillas de texto.</p>
			<p>Los atributos personalizados se agregan al formulario de pago, permitiendo capturar más información, como por ejemplo: La talla de un prenda de vestir o el color que desea el pagador.</p>
			<p>Para ingresar un nuevo atributo personalizable, haz clic en el botón <strong>Nuevo Atributo:</strong> </p>
			<div align="center">
				<figure> <a href="images/soluciones/boton03.jpg" data-fancybox="group2" data-caption="Clic nuevo atributo"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton03.jpg" alt="Clic nuevo atributo" /> </a>
					<figcaption>Clic nuevo atributo</figcaption>
				</figure>
			</div>
			<ul>
				<li>Ingresa en nombre del atributo, ejemplo: Talla.</li>
				<li> Selecciona si el atributo será un selector con opciones o un texto libre. </li>
				<li>Si seleccionaste selector con opciones, ingresa las opciones, cada una separada por comas.</li>
				<li> Finalmente haz clic en el botón <strong>Aceptar.</strong>
				</li>
			</ul>
			<div align="center">
				<figure> <a href="images/soluciones/boton04.jpg" data-fancybox="group2" data-caption="Agregar nuevo atributo"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton04.jpg" alt="Agregar nuevo atributo" /> </a>
					<figcaption>Agregar nuevo atributo</figcaption>
				</figure>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-4">Publicar tu botón de pago</h2>
			</div>
			<p>Al editar el botón de pago, busca la sección <strong>Accesos directos</strong> obtendrás un link que podrás pegar en tu muro de Facebook, en el timeline de Twitter u otra red social. Además encontrarás los códigos HTML de los distintos botones que podrás pegar en tu sitio web. </p>
			<div align="center">
				<figure> <a href="images/soluciones/boton051.jpg" data-fancybox="group3" data-caption="Publicar tu botón de pago"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton051.jpg" alt="Publicar tu botón de pago" /> </a>
					<figcaption>Publicar tu botón de pago</figcaption>
				</figure>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-5">Publicando en Facebook</h2>
			</div>
			<p>En tu página personal de Facebook o en tu Fan Page, crea un post y describe el producto o servicio que estás ofreciendo. 
			Luego, pega el link del botón de pago y Facebook cargará automáticamente la foto asociada al botón.
			</p>
			<p>Antes de publicar, podrás seleccionar entre la foto del producto y una imagen de nuestro botón de pago. Escoge la que quieras y postea. Ahora tus amigos o clientes podrán hacer clic sobre el botón y accederán directamente a Flow para concretar el pago. </p>
			<div align="center">
				<figure> <a href="images/soluciones/boton061.jpg" data-fancybox="group4" data-caption="Publicando en Facebook"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton061.jpg" alt="Publicando en Facebook" /> </a>
					<figcaption>Publicando en Facebook</figcaption>
				</figure>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-6">Tienda en Facebook</h2>
			</div>
			<p>Puedes tener una tienda gratuíta en tu página de Facebook. En esta tienda podrás recibir pagos mediante Flow utilizando los botones de pago. Conoce más en <a href="ayuda-tienda-facebook.php" title="Tienda Facebook">Tienda Facebook.</a>
			</p>
			<div align="center">
				<figure> <a href="images/soluciones/boton09.jpg" data-fancybox="group5" data-caption="Tienda en Facebook"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton09.jpg" alt="Tienda en Facebook" /> </a>
					<figcaption>Tienda en Facebook</figcaption>
				</figure>
			</div>
		</div>
		<div class="seccion fondo-claro">
            <div class="titulo-producto">
                <h2 id="target-marketplace">Marketplace de Facebook</h2>
            </div>
            <p>Utiliza el Marketplace de Facebook para vender fácilmente tus artículos nuevos o usados. Podrás utilizar los botones para recibir pagos mediante Flow.</p>
            <p>Una vez que te contactes con un cliente podrás utilizar el botón creado en Flow para recibir tus pagos. Sólo debes enviarle el link del botón mediante mensaje privado, email, red social u otros.</p>
            <div align="center">
                <figure> <a href="images/soluciones/boton11.jpg" data-fancybox="group6" data-caption="Tienda en Facebook"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton11.jpg" alt="Tienda en Facebook" /> </a>
                    <figcaption>Marketplace de Facebook</figcaption>
                </figure>
            </div>
        </div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-7">¿Cómo pagan tus clientes?</h2>
			</div>
			<p>Una vez que tu cliente hace clic en el botón, se despliega la página de Flow que permite realizar el pago.</p>
			<p>En ella se muestra la información del producto y su vendedor. Al acceder tus clientes podrán seleccionar el número de unidades de acuerdo a las unidades disponibles en caso de que hayas ingresado el stock. Los atributos personalizables se muestran a continuación del concepto y son obligatorios.</p>
			<p>Además de los atributos personalizables, el cliente deberá ingresar su email. De forma opcional podrá ingresar instrucciones como: dirección de envío y fecha de despacho, las que recibirás en el mail de aviso cuando se produzca el pago.</p>
			<div align="center">
				<figure> <a href="images/soluciones/boton071.png" data-fancybox="group7" data-caption="¿Cómo pagan tus clientes?"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton071.png" alt="¿Cómo pagan tus clientes?" /> </a>
					<figcaption>Botón de pago: Descripción</figcaption>
				</figure>
			</div>
			<div align="center">
				<figure> <a href="images/soluciones/boton071b.png" data-fancybox="group7" data-caption="¿Cómo pagan tus clientes?"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/boton071b.png" alt="¿Cómo pagan tus clientes?" /> </a>
					<figcaption>Botón de pago: Pago</figcaption>
				</figure>
			</div>
		</div>
	</div>
	<!-- FOOTER -->
<div id="footer" class="footer">
    <div class="container visible-lg visible-md">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6">
                <h5>Preguntas frecuentes</h5>
                <ul class="unstyled">
                    <li><a href="faq.php#pagar">Pagar con Flow</a>
                    </li>
                    <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                    </li>
                    <li><a href="faq.php#ayuda">Ayuda técnica</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Tarifas y condiciones</h5>
                    <ul class="unstyled">
                        <li><a href="tarifas.php">Tarifas vigentes</a>
                        </li>
                        <li><a href="terminos.php">Términos &amp; condiciones</a>
                        </li>
                        <li><a href="privacidad.php">Política de privacidad</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Contacto</h5>
                    <ul class="unstyled">
                        <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                        </li>
                        <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 cajaLogos">
                <h5>En Flow recibes pagos con: </h5>
                <ul class="unstyled">
                    <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container hidden-lg hidden-md">
        <div class="panel-default" id="accordionFooter" role="tablist" aria-multiselectable="true">
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter1">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter1" aria-expanded="true" aria-controls="collapseFooter1"> <i class="more-less fa fa-chevron-down"></i> Preguntas frecuentes </a> </h4>
                </div>
                <div id="collapseFooter1" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter1">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="faq.php#pagar">Pagar con Flow</a>
                            </li>
                            <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                            </li>
                            <li><a href="faq.php#ayuda">Ayuda técnica</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter2">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter2" aria-expanded="true" aria-controls="collapseFooter2"> <i class="more-less fa fa-chevron-down"></i> Tarifas y condiciones </a> </h4>
                </div>
                <div id="collapseFooter2" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter2">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tarifas.php">Tarifas vigentes</a>
                            </li>
                            <li><a href="terminos.php">Términos &amp; condiciones</a>
                            </li>
                            <li><a href="privacidad.php">Política de privacidad</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter3">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter3" aria-expanded="true" aria-controls="collapseFooter3"> <i class="more-less fa fa-chevron-down"></i> Contacto </a> </h4>
                </div>
                <div id="collapseFooter3" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter3">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                            </li>
                            <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter4">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter4" aria-expanded="true" aria-controls="collapseFooter4"> <i class="more-less fa fa-chevron-down"></i> En Flow recibes pagos con: </a> </h4>
                </div>
                <div id="collapseFooter4" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter4">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter5">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter5" aria-expanded="true" aria-controls="collapseFooter5"> <i class="more-less fa fa-chevron-down"></i> Seguridad </a> </h4>
                </div>
                <div id="collapseFooter5" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter5">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/seguro.php#sitelock"><img alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a> </li>
                            <li class="logosMediosPagos"> <a href="/seguro.php#pci"><img alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="socialFooter" class="social-footer" align="center">
    <div class="container">
        <div class="row">
            <div class="col-md-12"> 
                <div class="hidden-xs hidden-sm pull-left"><a href="/seguro.php#sitelock"><img class="img-responsive" alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a>
                </div>
                <a href="http://www.facebook.com/flow.cl" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-facebook fa-stack-1x"></i> </span></a> <a href="https://twitter.com/@flow_chile" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-twitter fa-stack-1x"></i> </span></a> <a href="https://www.instagram.com/flowpuntocl/" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-instagram fa-stack-1x"></i> </span></a> <a href="http://vimeo.com/flowvideos" target="_blank" class="hvr-grow"> <span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-vimeo fa-stack-1x"></i> </span></a> <a href="https://www.youtube.com/channel/UCIHMLt0pJDoTX19QJWpc5dg?view_as=subscriber" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-youtube-play fa-stack-1x"></i> </span></a>
                <div class="hidden-xs hidden-sm pull-right"><a href="/seguro.php#pci"><img class="img-responsive" alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- / FOOTER --> 

<!-- Modal Contactanos -->
<div class="modal fade" id="modalContactanos" tabindex="-1" role="dialog" aria-labelledby="modalContactanosLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>Contáctanos para mayor información </h2>
                </div>
            </div>
            <div class="modal-body">
                <p> ¿Quieres obtener este servicio? Puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<!-- Modal Pronto -->
<div class="modal fade" id="modalPronto" tabindex="-1" role="dialog" aria-labelledby="modalProntoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>¡Pronto! </h2>
                </div>
            </div>
            <div class="modal-body">
                <p>Estamos trabajando en este servicio, pronto se encontrará disponible. </p>
                <p>Recuerda que puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<!-- The scroll to top feature --> 
<a href="javascript:" id="return-to-top"> <i class="fa fa-chevron-up"> </i></a>	<!-- JS -->
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/fancybox/dist/jquery.fancybox.min.js"></script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.3.3.7.min.js"></script>
	<!-- JS  -->
	<script src="secciones-pagina/footer.js"></script>
</body>

</html>