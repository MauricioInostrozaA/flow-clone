<!DOCTYPE html>
<html lang="es" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">

<head>
	        
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TTPSNQC');</script>
<!-- End Google Tag Manager -->    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Flow - Plataforma de pagos online - Chile</title>
    <meta name="description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito">
    <meta name="keywords" content="plataforma de pagos, pagos online, pagar, cobrar, pagos en linea, pagos electronicos, ecommerce, tarjetas, credito, debito, redcompra, prepago, webpay, tarjetas de credito, visa, mastercard, magna, american express, sistema de pagos, recaudar, chile, cuotas, ventas online, transbank">
    <meta name="author" content="Flow">
    <meta property="og:title" content="Flow - Plataforma de pagos online - Chile"/>
    <meta property="og:description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito"/>
    <meta property="og:site_name" content="Flow"/>
    <meta property="og:type" content="website"/>
    <meta property="og:image" content="http://www.flow.cl/img/6.png"/>
    <meta property="og:image:width" content="400"/>
    <meta property="og:image:height" content="211"/>
    <meta property="og:image:alt" content="Flow Plataforma de pagos online"/>
    <meta property="og:url" content="http://www.flow.cl/cryptocompra.php"/>
    <link rel="canonical" href="http://www.flow.cl/cryptocompra.php" />
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/img/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/img/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
    <link rel="manifest" href="/img/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="/css/bootstrap.3.3.7.min.css">
    <link rel="stylesheet" href="/css/forms.css">
    <link rel="stylesheet" href="/css/flow.css">
    <link rel="stylesheet" href="/css/menu.css">
    <link rel="stylesheet" href="/css/footer.css?v=20191203">
    <link rel="stylesheet" href="/css/font-awesome.4.7.0.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato|Montserrat">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->
       <!-- CSS Propio -->
    <link rel="stylesheet" href="/css/colores.css">
    <link rel="stylesheet" href="/css/interior.css">
    <link rel="stylesheet" type="text/css" href="/js/fancybox/dist/jquery.fancybox.min.css">
	<style>
		#header img {
			width: 83%;
		}
	</style>
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTPSNQC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><!-- NAVBAR -->
<div id="mainNav" class="navbar yamm navbar-default navbar-fixed-top">
    <div class="container menuSuperior">
        <div class="navbar-header">
            <button type="button" data-toggle="collapse" data-target="#navbar-collapse-2" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a href="index.php" class="navbar-brand"><img src="images/header/logo-flow.svg"></a>
        </div>
        <div id="navbar-collapse-2" class="navbar-collapse collapse collapseHeader">
            <ul class="nav navbar-nav pull-left">
                <li><a href="info.php" class="menu">Conócenos</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu">Recibe pagos<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <!-- Content container to add padding -->
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="cobra-email.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/cobro-email.svg"> Cobra por email</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/carro-compra.svg">En tu carro de compras</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/mall.svg"> En tu propia tienda gratis</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="vende-presencialmente.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/venta-presencial.svg"> Vende presencialmente</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="redes-sociales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/redes-sociales.svg"> En redes sociales</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="soluciones-empresariales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/soluciones-empresariales.svg"> Soluciones empresariales </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="suscripciones.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/forma-recurrente.svg"> Suscripciones</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="web-sistema.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/web-sistema.svg"> En tu web o sistema computacional </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="reembolsos.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/reembolso.svg"> Reembolsos</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu" aria-expanded="false">Información técnica <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg">Integrar plugins de e-commerce</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="/docs/api.html" target="_blank">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica.svg">Documentación API Rest</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg"> Integrar Sumar.cl a tu sitio web</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="/faq.php"class="menu">Ayuda</a>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="http://comunicaciones-flow.cl/blog" target = "_blank" class="menu">Blog</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/register.php" class="menu">Regístrate</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/login.php" class="menu">Ingresa</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="visible-lg"><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default botonMenu">Regístrate</a>
                </li>
                <li class="visible-lg"><a href="app/web/login.php" class="btn btn-default btn-lg btn-flow-inv botonMenu">Ingresa</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- !NAVBAR -->	<div id="secondNavbar" class="navbar navbar-fixed-top second-navbar visible-lg">
		<div class="container">
			<div class="navbar-header pull-left second-nav">
				<ul class="nav navbar-nav">
					<li class="tituloSecond">Medios de pago</li>
				</ul>
			</div>
			<ul class="nav navbar-nav navbar-right">
				<li> <a href="javascript: history.go(-1)"><i class="fa fa-arrow-left" aria-hidden="true"></i> Volver</a> </li>
				<li class="divider-vertical"></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Accesos rápidos <i class="caret"></i></a>
					<ul class="dropdown-menu">
						<li class="sub"><a href="javascript:scroll_to_class('#target-0')">Inicio </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-z')">Activar medio de pago </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-1')">Pago en línea </a>
						</li>
					</ul>
				</li>
				<li class="divider-vertical"></li>
			</ul>
		</div>
	</div>
    <div class="container nopadding-movil">
        <div class="seccion fondo-claro">
            <div class="titulo-producto" id="porque">
                <h2 id = "target-0">CryptoCompra</h2>
            </div>
            <p>
				En Flow es posible <b>pagar</b> y <b>recibir pagos</b> mediante CryptoCompra de distintas formas:
            </p>
            <div class="row">
                <div class="col-xs-12 nopadding">
                    <div class="contenedorInteriorConocenos text-center"> <img src="images/medios-de-pago/cryptocompra/cm-sf.svg">
                        <p> 
                            <strong>Pago en línea:</strong> Pago mediante criptomonedas.
                        </p>
                    </div>
                </div>
            </div>
        </div>
		<div class="seccion fondo-claro">
	<div class="titulo-producto" id="que-es">
		<h2 id = "target-z">Soy comercio y quiero activar CryptoCompra en mi cuenta Flow</h2>
	</div>
	<p>
		1.- <b>Si aún no tienes una cuenta Flow,</b> puedes crear una haciendo <a href="app/web/register.php" target="_blank">click aquí.</a> En dicho formulario podrás seleccionar los medios de pago que desees activar.
		<br><br>
		2.- <b>Si ya tienes una cuenta Flow</b> y desea agregar a CryptoCompra a tus medios de pago, realiza los siguientes pasos:
		<ul>
			<li>Ingresa a tu cuenta Flow haciendo <a href="app/web/login.php" target="_blank">click aquí.</a></li>
			<li>Ingresa al menú <i>Mis datos</i>.</li>
			<li>Dirígete al final de la página y haz click en el botón <i>Modificar datos</i>.</li>
			<li>A continuación, recibirás un email con un link para modificar tus datos y medios de pago.</li>
			<li>Haz click en el link obtenido y dirígete a la sección <i>Medios de pago</i>.</li>
			<li>Selecciona el o los medios de pago que desees activar y elige la tarifa.</li>
			<li>Finalmente, debes aceptar los Términos y condiciones de uso y hacer click en el botón <i>Enviar</i>.</li>
		</ul>
	</p>
</div>        <div class="seccion fondo-claro">
            <div class="titulo-producto" id="que-es">
                <h2 id = "target-1">Pago en línea</h2>
            </div>
            <p>
                Esta modalidad permite a un determinado cliente pagar en línea utilizando: 
            </p>
			<ul>
				<li>Criptomonedas:
				<br/>
                    <img src="images/medios-de-pago/cryptocompra/bitcoin.png" class="img-responsive img-rounded img-thumbnail" alt="Bitcoin" title="Bitcoin"/>
                    <img src="images/medios-de-pago/cryptocompra/ethereum.png" class="img-responsive img-rounded img-thumbnail" alt="Ethereum" title="Ethereum"/>
                    <img src="images/medios-de-pago/cryptocompra/stellar.png" class="img-responsive img-rounded img-thumbnail" alt="Stellar" title="Stellar"/>
					<br/><br/>
				</li>
            </ul>   
            <p>
                Importante: Con el objetivo de garantizar que el comercio reciba el valor de venta pactado en pesos chilenos, CryptoCompra congela 
				el valor equivalente en criptomonedas por un período de 15 minutos. 
				<br/><br/>
				Para realizar un pago en línea mediante CryptoCompra, el cliente debe seguir los pasos descritos a continuación. 
				Una vez que concrete el pago, Flow notificará inmediatamente al comercio (usuario mandante) sobre el pago realizado.
				<br/><br/>
                1.- En primer lugar, el cliente debe seleccionar CryptoCompra como medio de pago:
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/1.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/1.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
			<hr>
            <p>
                2.- A continuación, debe seleccionar el tipo de pago, el cual puede ser <b>Bitcoin</b>, <b>Stellar</b> o <b>Ethereum</b>:</strong>
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/2.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/2.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
			<hr>
            <p>
                3.- En el siguiente paso, el cliente debe confirmar su email:
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/3.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/3.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
			<hr>
            <p>
                4.- A continuación, el cliente puede pagar de 3 formas diferentes:
            </p>
            <ul>
                <li>Pago desde una Wallet de CryptoCompra (instantáneo), utilizando la APP de CryptoCompra.</li>
				<li>Pago desde una Wallet de CryptoCompra (instantáneo), desde la plataforma (web) de CryptoCompra.</li>
                <li>Paga desde una Wallet externa a CryptoCompra (no instantáneo).</li>
            </ul>
			<br>
			<p>
				<u><strong>4.1 Pago desde una Wallet de CryptoCompra (instantáneo), utilizando la APP de CryptoCompra:</strong></u>
				<br><br>
				4.1.1 Si el cliente tiene la APP de CryptoCompra instalada en su smartphone, debe abrir la aplicación y hacer click 
				en el ícono de cámara <img src="/images/medios-de-pago/cryptocompra/camara.jpg"> en la APP de CryptoCompra:
			</p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/4.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/4.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
            <p>
                4.1.2 A continuación el cliente debe escanear el código, con lo cual podrá visualizar el monto y la dirección a la que se enviará. Para confirmar debe hacer click en <i>Enviar</i>:
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/5.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/5.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
            <p>
                4.1.3 Es importante considerar que los clientes de CryptoCompra tienen aprobado un límite diario para pagos o transferencias sin necesidad de usar <b>2factor</b>. 
                Los límites son definidos por cada cliente en la plataforma de CryptoCompra y el máximo estándar por cada criptomoneda es: 0.07 ETH, 140 XLM y 0.005 BTC: 
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/6.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/6.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
            <p>
                4.1.4 Haciendo <a href="https://www.cryptomkt.com/account#mobile_tab" target="_blank">click aquí</a>, el cliente puede definir límites de pago 
				con criptomonedas sin necesidad de utilizar <b>2factor</b>:
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/7.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/7.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
			<br>
            <p>
				<u><strong>4.2 Pago desde una Wallet de CryptoCompra (instantáneo), desde la plataforma (web) de CryptoCompra:</strong></u>
				<br><br>
				4.2.1 Para que el pago sea realizado directamente desde la plataforma de CryptoCompra, el cliente debe estar conectado a la plataforma de CryptoCompra.
				El cliente debe hacer click en el botón <i>Pagar con CryptoMarket:</i>
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/8.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/8.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
            <p>
                4.2.2 Al hacer click en dicho botón, se abrirá automáticamente la página de CryptoCompra donde se notificará al cliente del valor total de la compra y se solicitará su confirmación:
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/9.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/9.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
            <p>
                4.2.3 Al confirmar, se procederá a confirmar la operación y a validar el pago.
            </p>
			<br>
            <p>
				<u><strong>4.3 Paga desde una Wallet externa a CryptoCompra (no instantáneo):</strong></u>
				<br><br>
				4.3.1 Para una mejor experiencia de pagos, se recomienda el uso del Wallet de CryptoCompra. Todos los pagos son instantáneos y no tendrán ningún costo adicional al cliente.
				<br><br>               
				4.3.2 Al utilizar esta forma de pago, los pagos serán ejecutados utilizando la Blockchain de cada criptomoneda. Los tiempos de transacción serán en acuerdo con la Blockchain utilizada y posibles costos adicionales serán aplicados al cliente en acuerdo con el tipo de transferencia realizado.
				<br><br>
                4.3.3 Para realizar el pago desde otro Wallet que no sea de CryptoCompra se debe hacer click en la pestaña <i>Copiar</i> y se obtendrá el monto total y dirección (además de MEMO en caso de ser por medio de Stellar):
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/10.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/10.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
            <p>
                4.3.4 El cliente debe copiar la dirección del Wallet de destino y el monto correspondiente en criptomonedas para ejecutar la transferencia.
				Luego, estos valores se deben ingresar en el wallet externo, verificando detalladamente que se haya ingresado el mismo monto y misma criptomoneda.
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/11.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/11.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
			<hr>
			<p>
                5.- Una vez que se haya concretado el pago, CryptoCompra confirmará el pago en línea.
			</p>
			<hr>
			<p>
                6.- A su vez, de forma inmediata, Flow notificará el pago realizado:
                <ul>
                    <li>Se enviará un aviso de pago realizado al comercio.</li>
                    <li>Se enviará un comprobante de pago al cliente.</li>
                    <li>Si el comercio utiliza algún API de integración, se notificará en línea a su sistema sobre el pago realizado.</li>
                </ul>
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/12.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/12.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
			<hr>
            <p>
                7.- Finalmente, cuando el cliente concrete el proceso de pago:
                <ul>
                    <li>Será direccionado a la página de éxito de Flow, donde se le mostrará información de su pago.</li>
                    <li>En caso que el comercio utilice algún API de integración, esta página no se mostrará
                    y será direccionado a la página de éxito del comercio.</li>
                </ul>
            </p>
            <div align="center">
                <figure> 
                    <a href="images/medios-de-pago/cryptocompra/13.png" data-fancybox="group-img" data-caption="cryptocompra">
                        <img class="img-responsive img-rounded img-thumbnail" src="images/medios-de-pago/cryptocompra/13.png" alt="cryptocompra"/>
                    </a>
                </figure>
            </div>
        </div>
    </div>
	<!-- FOOTER -->
<div id="footer" class="footer">
    <div class="container visible-lg visible-md">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6">
                <h5>Preguntas frecuentes</h5>
                <ul class="unstyled">
                    <li><a href="faq.php#pagar">Pagar con Flow</a>
                    </li>
                    <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                    </li>
                    <li><a href="faq.php#ayuda">Ayuda técnica</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Tarifas y condiciones</h5>
                    <ul class="unstyled">
                        <li><a href="tarifas.php">Tarifas vigentes</a>
                        </li>
                        <li><a href="terminos.php">Términos &amp; condiciones</a>
                        </li>
                        <li><a href="privacidad.php">Política de privacidad</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Contacto</h5>
                    <ul class="unstyled">
                        <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                        </li>
                        <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 cajaLogos">
                <h5>En Flow recibes pagos con: </h5>
                <ul class="unstyled">
                    <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container hidden-lg hidden-md">
        <div class="panel-default" id="accordionFooter" role="tablist" aria-multiselectable="true">
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter1">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter1" aria-expanded="true" aria-controls="collapseFooter1"> <i class="more-less fa fa-chevron-down"></i> Preguntas frecuentes </a> </h4>
                </div>
                <div id="collapseFooter1" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter1">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="faq.php#pagar">Pagar con Flow</a>
                            </li>
                            <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                            </li>
                            <li><a href="faq.php#ayuda">Ayuda técnica</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter2">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter2" aria-expanded="true" aria-controls="collapseFooter2"> <i class="more-less fa fa-chevron-down"></i> Tarifas y condiciones </a> </h4>
                </div>
                <div id="collapseFooter2" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter2">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tarifas.php">Tarifas vigentes</a>
                            </li>
                            <li><a href="terminos.php">Términos &amp; condiciones</a>
                            </li>
                            <li><a href="privacidad.php">Política de privacidad</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter3">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter3" aria-expanded="true" aria-controls="collapseFooter3"> <i class="more-less fa fa-chevron-down"></i> Contacto </a> </h4>
                </div>
                <div id="collapseFooter3" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter3">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                            </li>
                            <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter4">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter4" aria-expanded="true" aria-controls="collapseFooter4"> <i class="more-less fa fa-chevron-down"></i> En Flow recibes pagos con: </a> </h4>
                </div>
                <div id="collapseFooter4" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter4">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter5">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter5" aria-expanded="true" aria-controls="collapseFooter5"> <i class="more-less fa fa-chevron-down"></i> Seguridad </a> </h4>
                </div>
                <div id="collapseFooter5" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter5">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/seguro.php#sitelock"><img alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a> </li>
                            <li class="logosMediosPagos"> <a href="/seguro.php#pci"><img alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="socialFooter" class="social-footer" align="center">
    <div class="container">
        <div class="row">
            <div class="col-md-12"> 
                <div class="hidden-xs hidden-sm pull-left"><a href="/seguro.php#sitelock"><img class="img-responsive" alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a>
                </div>
                <a href="http://www.facebook.com/flow.cl" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-facebook fa-stack-1x"></i> </span></a> <a href="https://twitter.com/@flow_chile" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-twitter fa-stack-1x"></i> </span></a> <a href="https://www.instagram.com/flowpuntocl/" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-instagram fa-stack-1x"></i> </span></a> <a href="http://vimeo.com/flowvideos" target="_blank" class="hvr-grow"> <span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-vimeo fa-stack-1x"></i> </span></a> <a href="https://www.youtube.com/channel/UCIHMLt0pJDoTX19QJWpc5dg?view_as=subscriber" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-youtube-play fa-stack-1x"></i> </span></a>
                <div class="hidden-xs hidden-sm pull-right"><a href="/seguro.php#pci"><img class="img-responsive" alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- / FOOTER --> 

<!-- Modal Contactanos -->
<div class="modal fade" id="modalContactanos" tabindex="-1" role="dialog" aria-labelledby="modalContactanosLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>Contáctanos para mayor información </h2>
                </div>
            </div>
            <div class="modal-body">
                <p> ¿Quieres obtener este servicio? Puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<!-- Modal Pronto -->
<div class="modal fade" id="modalPronto" tabindex="-1" role="dialog" aria-labelledby="modalProntoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>¡Pronto! </h2>
                </div>
            </div>
            <div class="modal-body">
                <p>Estamos trabajando en este servicio, pronto se encontrará disponible. </p>
                <p>Recuerda que puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<!-- The scroll to top feature --> 
<a href="javascript:" id="return-to-top"> <i class="fa fa-chevron-up"> </i></a>	<!-- JS -->
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/fancybox/dist/jquery.fancybox.min.js"></script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.3.3.7.min.js"></script>
	<!-- JS  -->
	<script src="secciones-pagina/footer.js"></script>
	<script src="app/js/flowWeb.js?v=20160530" type="text/javascript"></script>
</body>
</html>