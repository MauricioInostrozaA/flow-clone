<!DOCTYPE html>
<html lang="es">
<head>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TTPSNQC');</script>
<!-- End Google Tag Manager -->

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>Flow - Plataforma de pagos online - Chile</title>
<meta name="keywords" content="pagos online, pagar, cobrar, tarjetas, credito, debito, redcompra, webpay, tarjetas de credito, visa, mastercard, magna, american express, sistema de pagos, plataforma de pagos, recaudar, chile, cuotas, ventas online, transbank">
<meta name="description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito">
<meta name="author" content="Flow">
<meta property="og:title" content="Flow"/>
<meta property="og:description" content="Plataforma de pagos online"/>
<meta property="og:site_name" content="flow.cl"/>
<meta property="og:image" content="http://www.flow.cl/img/flow.png"/>
<meta property="og:image" content="http://www.flow.cl/img/6.png"/>
<meta property="og:url" content="http://www.flow.cl"/>
<meta name="format-detection" content="telephone=no"/>
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon"/>
<link rel="apple-touch-icon" sizes="57x57" href="/img/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="/img/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
<link rel="manifest" href="/img/manifest.json">

<!-- Bootstrap -->
<link rel="stylesheet" href="/css/bootstrap.3.3.7.min.css">
<link href="/css/forms.css" rel="stylesheet">
<link rel="stylesheet" href="/css/menu.css">
<link rel="stylesheet" href="/css/footer.css?v=20191203">
<link rel="stylesheet" href="/css/colores.css">
<link rel="stylesheet" href="/css/flow.css">
<link rel="stylesheet" href="/css/interior.css?v=20190325">
<link href="/css/font-awesome.4.7.0.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato|Montserrat" rel="stylesheet">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

<link rel="stylesheet" href="../../css/forms.css">
<link rel="stylesheet" href="../../css/login.css">

<style>
#header img {
	width: 40%;
}
</style>

<script src='https://www.google.com/recaptcha/api.js?render=6LfHRu0UAAAAABatB0vVI7AygcnAExGo0Qdf9vby'></script>
</head>

<body>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTPSNQC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- NAVBAR -->
<div id="mainNav" class="navbar yamm navbar-default navbar-fixed-top">
	<div class="container menuSuperior">
		<div class="navbar-header">
			<button type="button" data-toggle="collapse" data-target="#navbar-collapse-2" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
			<a href="/index.php" class="navbar-brand"><img src="/images/header/logo-flow.svg"></a>
		</div>
		<div id="navbar-collapse-2" class="navbar-collapse collapse collapseHeader">
			<ul class="nav navbar-nav pull-left">
				<li><a href="/info.php" class="menu">Conócenos</a>
				</li>
				<li class="hidden-lg">
					<hr class="barra-calipso">
				</li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu">Recibe pagos<b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li>
							<!-- Content container to add padding -->
							<div class="yamm-content">
								<div class="row">
									<ul class="col-sm-4 list-unstyled">
										<li class="opcionMenu">
											<a href="/cobra-email.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/cobro-email.svg"> Cobra por email</div>
											</a>
										</li>
										<hr class="barra-calipso">
										<li class="opcionMenu">
											<a href="/redes-sociales.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/redes-sociales.svg"> En redes sociales</div>
											</a>
										</li>
										<hr class="barra-calipso">
										<li class="opcionMenu">
											<a href="/web-sistema.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/web-sistema.svg"> En tu web o sistema computacional </div>
											</a>
										</li>
										<hr class="barra-calipso hidden-lg">
									</ul>
									<ul class="col-sm-4 list-unstyled">
										<li class="opcionMenu">
											<a href="/suscripciones.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/forma-recurrente.svg"> Suscripciones</div>
											</a>
										</li>
										<hr class="barra-calipso">
										<li class="opcionMenu">
											<a href="/tienda-facebook.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/tienda-facebook.svg">En tu tienda de Facebook</div>
											</a>
										</li>
										<hr class="barra-calipso">
										<li class="opcionMenu">
											<a href="/soluciones-empresariales.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/soluciones-empresariales.svg"> Soluciones empresariales </div>
											</a>
										</li>
										<hr class="barra-calipso hidden-lg">
									</ul>
									<ul class="col-sm-4 list-unstyled">
										<li class="opcionMenu">
											<a href="/carro-compras.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/carro-compra.svg">En tu carro de compras</div>
											</a>
										</li>
										<hr class="barra-calipso">
										<li class="opcionMenu">
											<a href="/tienda-gratis.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/mall.svg"> En tu propia tienda gratis</div>
											</a>
										</li>
										<hr class="barra-calipso">
										<li class="opcionMenu">
											<a href="/reembolsos.php">
												<div><img class="imagenMenu pull-left hidden-xs" src="/images/iconos/svg/reembolso.svg"> Reembolsos</div>
											</a>
										</li>
										<hr class="barra-calipso hidden-lg">
									</ul>
								</div>
							</div>
						</li>
					</ul>
				</li>
				<li class="hidden-lg">
					<hr class="barra-calipso">
				</li>
				<li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu" aria-expanded="false">Información técnica <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li>
							<div class="yamm-content">
								<div class="row">
									<ul class="col-sm-6 list-unstyled">
										<li class="opcionMenu">
											<a href="/carro-compras.php">
												<div><img class="bullet pull-left hidden-xs" src="/images/iconos/svg/info-tecnica2.svg">Integrar plugins de e-commerce</div>
											</a>
										</li>
										<hr class="barra-calipso">
										<li class="opcionMenu">
											<a href="/docs/api.html" target="_blank">
												<div><img class="bullet pull-left hidden-xs" src="/images/iconos/svg/info-tecnica.svg">Documentación API Rest</div>
											</a>
										</li>
										<hr class="barra-calipso hidden-lg">
									</ul>
									<ul class="col-sm-6 list-unstyled">
										<li class="opcionMenu">
											<a href="/tienda-gratis.php">
												<div><img class="bullet pull-left hidden-xs" src="/images/iconos/svg/info-tecnica2.svg"> Integrar Sumar.cl a tu sitio web</div>
											</a>
										</li>
										<hr class="barra-calipso">
									</ul>
								</div>
							</div>
						</li>
					</ul>
				</li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="/faq.php" class="menu">Ayuda</a>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="http://comunicaciones-flow.cl/blog" target = "_blank" class="menu">Blog</a>
                </li>
				<li class="hidden-lg">
					<hr class="barra-calipso">
				</li>
				<li class="visible-xs visible-sm visible-md"><a href="/app/web/register.php" class="menu">Regístrate</a>
				</li>
				<li class="hidden-lg">
					<hr class="barra-calipso">
				</li>
				<li class="visible-xs visible-sm visible-md"><a href="/app/web/login.php" class="menu">Ingresa</a>
				</li>
				<li class="hidden-lg">
					<hr class="barra-calipso">
				</li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="visible-lg"><a href="/app/web/register.php" class="btn btn-default btn-lg btn-flow-default botonMenu">Regístrate</a>
				</li>
				<li class="visible-lg"><a href="/app/web/login.php" class="btn btn-default btn-lg btn-flow-inv botonMenu">Ingresa</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<!-- !NAVBAR -->
<div id="secondNavbar" class="navbar navbar-fixed-top second-navbar visible-lg">
  <div class="container">
    <div class="navbar-header pull-left second-nav">
      <ul class="nav navbar-nav">
        <li class="tituloSecond">Ingresar</li>
      </ul>
    </div>
  </div>
</div>
<div class="container nopadding-movil cajaIngreso">
  <div class="col-md-offset-3 col-md-6 nopaddingInterno">
    <div class="panel panel-default">
      <div class="flow-frame-form nopaddingInterno">
        <div class="titulo-producto">
          <h2> Bienvenido a Flow </h2>
        </div>
        <div id="recaptcha" data-siteKey=6LfHRu0UAAAAABatB0vVI7AygcnAExGo0Qdf9vby></div>
        <form role="form" id="formLogin">
          <label for="login-username">Correo electrónico de login</label>
          <div id="usuario">
            <input id="email" name="email" type="email" class="form-control" placeholder="Email">
          </div>
          <label for="login-password">Password</label>
          <div id="contrasena">
            <input id="psw" name="psw" type="password" autocomplete="new-password" class="form-control" placeholder="Password">
          </div>
          <input type="hidden" id="token" name="token" value="1514039180" />
          <div id="loginPopup" class="alert alert-danger hide"> <strong>Error: </strong>
            <label></label>
          </div>
          
                    <input id="pre_p" name="edita" type="hidden" value="0" />
                    <div class="contenedorEnviar" align="center">
            <button id="btnSubmit" class="btn btn-default btn-lg btn-flow-default botonIngreso" type="submit">Ingresar</button>
          </div>
          
          <div class="form-group">
            <div class="col-lg-6">
              <div class="contenedorBajoLogin" align="center"> <a href="olvide.php" class="textoLogin"><i class="fa fa-question-circle-o" aria-hidden="true"></i> No recuerdo mi password </a> </div>
            </div>
            <div class="col-lg-6">
              <div class="contenedorBajoLogin" align="center"> <a href="../../app/web/register.php" class="textoLogin"><i class="fa fa-user-plus" aria-hidden="true"></i> No tengo cuenta de Flow </a> </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- FOOTER -->
<div id="footer" class="footer">
	<div class="container visible-lg visible-md">
		<div class="row">
			<div class="col-md-3 col-sm-6 col-xs-6">
				<h5>Preguntas frecuentes</h5>
				<ul class="unstyled">
					<li><a href="/faq.php#pagar">Pagar con Flow</a>	</li>
					<li><a href="/faq.php#pago">Recibir pagos con Flow</a></li>
					<li><a href="/faq.php#ayuda">Ayuda técnica</a></li>
				</ul>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-6">
				<div>
					<h5>Tarifas y condiciones</h5>
					<ul class="unstyled">
						<li><a href="/tarifas.php">Tarifas vigentes</a></li>
						<li><a href="/terminos.php">Términos &amp; condiciones</a></li>
						<li><a href="/privacidad.php">Política de privacidad</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-6">
				<div>
					<h5>Contacto</h5>
					<ul class="unstyled">
						<li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a></li>
						<li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-6 cajaLogos">
				<h5>En Flow recibes pagos con: </h5>
				<ul class="unstyled">
                    <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                </ul>
			</div>
		</div>
	</div>
	<div class="container hidden-lg hidden-md">
		<div class="panel-default" id="accordionFooter" role="tablist" aria-multiselectable="true">
			<div class="panel panelFooter">
				<div class="panel-heading" role="tab" id="headingFooter1">
					<h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter1" aria-expanded="true" aria-controls="collapseFooter1"> <i class="more-less fa fa-chevron-down"></i> Preguntas frecuentes </a> </h4>
				</div>
				<div id="collapseFooter1" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter1">
					<div class="panel-body">
						<ul class="unstyled">
							<li><a href="/faq.php#pagar.php">Pagar con Flow</a></li>
							<li><a href="/faq.php#pago">Recibir pagos con Flow</a></li>
							<li><a href="/faq.php#ayuda">Ayuda técnica</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="panel panelFooter">
				<div class="panel-heading" role="tab" id="headingFooter2">
					<h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter2" aria-expanded="true" aria-controls="collapseFooter2"> <i class="more-less fa fa-chevron-down"></i> Tarifas y condiciones </a> </h4>
				</div>
				<div id="collapseFooter2" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter2">
					<div class="panel-body">
						<ul class="unstyled">
							<li><a href="/tarifas.php">Tarifas vigentes</a></li>
							<li><a href="/terminos.php">Términos &amp; condiciones</a></li>
							<li><a href="/privacidad.php">Política de privacidad</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="panel panelFooter">
				<div class="panel-heading" role="tab" id="headingFooter3">
					<h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter3" aria-expanded="true" aria-controls="collapseFooter3"> <i class="more-less fa fa-chevron-down"></i> Contacto </a> </h4>
				</div>
				<div id="collapseFooter3" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter3">
					<div class="panel-body">
						<ul class="unstyled">
							<li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a></li>
							<li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="panel panelFooter">
				<div class="panel-heading" role="tab" id="headingFooter4">
					<h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter4" aria-expanded="true" aria-controls="collapseFooter4"> <i class="more-less fa fa-chevron-down"></i> En Flow recibes pagos con: </a> </h4>
				</div>
				<div id="collapseFooter4" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter4">
					<div class="panel-body">
						<ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                        </ul>
					</div>
				</div>
			</div>
			<div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter5">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter5" aria-expanded="true" aria-controls="collapseFooter5"> <i class="more-less fa fa-chevron-down"></i> Seguridad </a> </h4>
                </div>
                <div id="collapseFooter5" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter5">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/seguro.php#sitelock"><img alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a> </li>
                            <li class="logosMediosPagos"> <a href="/seguro.php#pci"><img alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
		</div>
	</div>
</div>
<div id="socialFooter" class="social-footer" align="center">
	<div class="container">
		<div class="row">
			<div class="col-md-12"> 
			    <div class="hidden-xs hidden-sm pull-left"><a href="/seguro.php#sitelock"><img class="img-responsive" alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a>
                </div>
			    <a href="http://www.facebook.com/flow.cl" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-facebook fa-stack-1x"></i> </span></a> <a href="https://twitter.com/@flow_chile" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-twitter fa-stack-1x"></i> </span></a> <a href="https://www.instagram.com/flowpuntocl/" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-instagram fa-stack-1x"></i> </span></a> <a href="http://vimeo.com/flowvideos" target="_blank" class="hvr-grow"> <span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-vimeo fa-stack-1x"></i> </span></a> <a href="https://www.youtube.com/channel/UCIHMLt0pJDoTX19QJWpc5dg?view_as=subscriber" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-youtube-play fa-stack-1x"></i> </span></a>
				<div class="hidden-xs hidden-sm pull-right"><a href="/seguro.php#pci"><img class="img-responsive" alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a>
                </div>
			</div>
		</div>
	</div>
</div>
<!-- / FOOTER --> 

<!-- Modal Contactanos -->
<div class="modal fade" id="modalContactanos" tabindex="-1" role="dialog" aria-labelledby="modalContactanosLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="titulo-modal">
					<h2>Contáctanos para mayor información </h2>
				</div>
			</div>
			<div class="modal-body">
				<p> ¿Quieres obtener este servicio? Puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
				<div class="row text-center">
					<a href="tel:+56 2 2583 0102">
						<p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
					</a>
					<a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
						<p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
					</a>
				</div>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<!-- Modal Pronto -->
<div class="modal fade" id="modalPronto" tabindex="-1" role="dialog" aria-labelledby="modalProntoLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="titulo-modal">
					<h2>¡Pronto! </h2>
				</div>
			</div>
			<div class="modal-body">
				<p>Estamos trabajando en este servicio, pronto se encontrará disponible. </p>
				<p>Recuerda que puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
				<div class="row text-center">
					<a href="tel:+56 2 2583 0102">
						<p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
					</a>
					<a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
						<p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
					</a>
				</div>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<!-- The scroll to top feature --> 
<a href="javascript:" id="return-to-top"> <i class="fa fa-chevron-up"> </i></a> 
<!-- JS --> 
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="../../js/jquery-1.11.3.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="../../js/bootstrap.3.3.7.min.js"></script> 
<!-- JS  --> 
<script src="../../secciones-pagina/footer.js"></script> 
<script src="../js/jquery.validate.min.js" type="text/javascript"></script> 
<script src="../js/flowWeb.js?v=20160530" type="text/javascript"></script> 
<script src="js/login.js?v=20200423" type="text/javascript"></script>
</body>
</html>