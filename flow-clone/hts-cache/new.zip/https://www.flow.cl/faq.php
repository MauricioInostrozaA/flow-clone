<!DOCTYPE html>
<html lang="es" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">
<head>
	    
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TTPSNQC');</script>
<!-- End Google Tag Manager -->    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Flow - Plataforma de pagos online - Chile</title>
    <meta name="description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito">
    <meta name="keywords" content="plataforma de pagos, pagos online, pagar, cobrar, pagos en linea, pagos electronicos, ecommerce, tarjetas, credito, debito, redcompra, prepago, webpay, tarjetas de credito, visa, mastercard, magna, american express, sistema de pagos, recaudar, chile, cuotas, ventas online, transbank">
    <meta name="author" content="Flow">
    <meta property="og:title" content="Flow - Plataforma de pagos online - Chile"/>
    <meta property="og:description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito"/>
    <meta property="og:site_name" content="Flow"/>
    <meta property="og:type" content="website"/>
    <meta property="og:image" content="http://www.flow.cl/img/6.png"/>
    <meta property="og:image:width" content="400"/>
    <meta property="og:image:height" content="211"/>
    <meta property="og:image:alt" content="Flow Plataforma de pagos online"/>
    <meta property="og:url" content="http://www.flow.cl/faq.php"/>
    <link rel="canonical" href="http://www.flow.cl/faq.php" />
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/img/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/img/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
    <link rel="manifest" href="/img/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="/css/bootstrap.3.3.7.min.css">
    <link rel="stylesheet" href="/css/forms.css">
    <link rel="stylesheet" href="/css/flow.css">
    <link rel="stylesheet" href="/css/menu.css">
    <link rel="stylesheet" href="/css/footer.css?v=20191203">
    <link rel="stylesheet" href="/css/font-awesome.4.7.0.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato|Montserrat">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->
       <link rel="stylesheet" href="/css/colores.css">
    <link rel="stylesheet" href="/css/interior.css">
    <link rel="stylesheet" type="text/css" href="/js/fancybox/dist/jquery.fancybox.min.css">
    <link rel="stylesheet" href="/css/helpDesk.css">
	<style>
		#header img {
			width: 40%;
		}
	</style>
</head>
<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTPSNQC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><!-- NAVBAR -->
<div id="mainNav" class="navbar yamm navbar-default navbar-fixed-top">
    <div class="container menuSuperior">
        <div class="navbar-header">
            <button type="button" data-toggle="collapse" data-target="#navbar-collapse-2" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a href="index.php" class="navbar-brand"><img src="images/header/logo-flow.svg"></a>
        </div>
        <div id="navbar-collapse-2" class="navbar-collapse collapse collapseHeader">
            <ul class="nav navbar-nav pull-left">
                <li><a href="info.php" class="menu">Conócenos</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu">Recibe pagos<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <!-- Content container to add padding -->
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="cobra-email.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/cobro-email.svg"> Cobra por email</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/carro-compra.svg">En tu carro de compras</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/mall.svg"> En tu propia tienda gratis</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="vende-presencialmente.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/venta-presencial.svg"> Vende presencialmente</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="redes-sociales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/redes-sociales.svg"> En redes sociales</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="soluciones-empresariales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/soluciones-empresariales.svg"> Soluciones empresariales </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="suscripciones.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/forma-recurrente.svg"> Suscripciones</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="web-sistema.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/web-sistema.svg"> En tu web o sistema computacional </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="reembolsos.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/reembolso.svg"> Reembolsos</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu" aria-expanded="false">Información técnica <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg">Integrar plugins de e-commerce</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="/docs/api.html" target="_blank">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica.svg">Documentación API Rest</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg"> Integrar Sumar.cl a tu sitio web</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="/faq.php"class="menu">Ayuda</a>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="http://comunicaciones-flow.cl/blog" target = "_blank" class="menu">Blog</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/register.php" class="menu">Regístrate</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/login.php" class="menu">Ingresa</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="visible-lg"><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default botonMenu">Regístrate</a>
                </li>
                <li class="visible-lg"><a href="app/web/login.php" class="btn btn-default btn-lg btn-flow-inv botonMenu">Ingresa</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- !NAVBAR -->	<div id="secondNavbar" class="navbar navbar-fixed-top second-navbar visible-lg">
		<div class="container">
			<div class="navbar-header pull-left second-nav">
				<ul class="nav navbar-nav">
					<li class="tituloSecond">Centro de ayuda y preguntas frecuentes</li>
				</ul>
			</div>
			<ul class="nav navbar-nav navbar-right">
                <li> <a href="javascript: history.go(-1)"><i class="fa fa-arrow-left" aria-hidden="true"></i> Volver</a> </li>
                <li class="divider-vertical"></li>
            </ul>
            <ul class="nav navbar-nav navbar-right" id="secondNavbarOptions">
                <li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Accesos rápidos <i class="caret"></i></a>
                    <ul class="dropdown-menu" id="subMenu">
                    </ul>
                </li>
                <li class="divider-vertical"></li>
            </ul>
		</div>
	</div>
	<div class="seccion fondo-claro" id="content">
		<div id="helpPanels" class="container">
			<div class="titulo-producto visible-xs visible-sm visible-md">
				<h2>Centro de ayuda y preguntas frecuentes</h2>
			</div>
			<br class="visible-lg">
			<div id="faqSection">
			</div>
		</div>
	</div>
	<!-- FOOTER -->
<div id="footer" class="footer">
    <div class="container visible-lg visible-md">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6">
                <h5>Preguntas frecuentes</h5>
                <ul class="unstyled">
                    <li><a href="faq.php#pagar">Pagar con Flow</a>
                    </li>
                    <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                    </li>
                    <li><a href="faq.php#ayuda">Ayuda técnica</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Tarifas y condiciones</h5>
                    <ul class="unstyled">
                        <li><a href="tarifas.php">Tarifas vigentes</a>
                        </li>
                        <li><a href="terminos.php">Términos &amp; condiciones</a>
                        </li>
                        <li><a href="privacidad.php">Política de privacidad</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Contacto</h5>
                    <ul class="unstyled">
                        <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                        </li>
                        <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 cajaLogos">
                <h5>En Flow recibes pagos con: </h5>
                <ul class="unstyled">
                    <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container hidden-lg hidden-md">
        <div class="panel-default" id="accordionFooter" role="tablist" aria-multiselectable="true">
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter1">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter1" aria-expanded="true" aria-controls="collapseFooter1"> <i class="more-less fa fa-chevron-down"></i> Preguntas frecuentes </a> </h4>
                </div>
                <div id="collapseFooter1" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter1">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="faq.php#pagar">Pagar con Flow</a>
                            </li>
                            <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                            </li>
                            <li><a href="faq.php#ayuda">Ayuda técnica</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter2">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter2" aria-expanded="true" aria-controls="collapseFooter2"> <i class="more-less fa fa-chevron-down"></i> Tarifas y condiciones </a> </h4>
                </div>
                <div id="collapseFooter2" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter2">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tarifas.php">Tarifas vigentes</a>
                            </li>
                            <li><a href="terminos.php">Términos &amp; condiciones</a>
                            </li>
                            <li><a href="privacidad.php">Política de privacidad</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter3">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter3" aria-expanded="true" aria-controls="collapseFooter3"> <i class="more-less fa fa-chevron-down"></i> Contacto </a> </h4>
                </div>
                <div id="collapseFooter3" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter3">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                            </li>
                            <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter4">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter4" aria-expanded="true" aria-controls="collapseFooter4"> <i class="more-less fa fa-chevron-down"></i> En Flow recibes pagos con: </a> </h4>
                </div>
                <div id="collapseFooter4" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter4">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter5">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter5" aria-expanded="true" aria-controls="collapseFooter5"> <i class="more-less fa fa-chevron-down"></i> Seguridad </a> </h4>
                </div>
                <div id="collapseFooter5" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter5">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/seguro.php#sitelock"><img alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a> </li>
                            <li class="logosMediosPagos"> <a href="/seguro.php#pci"><img alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="socialFooter" class="social-footer" align="center">
    <div class="container">
        <div class="row">
            <div class="col-md-12"> 
                <div class="hidden-xs hidden-sm pull-left"><a href="/seguro.php#sitelock"><img class="img-responsive" alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a>
                </div>
                <a href="http://www.facebook.com/flow.cl" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-facebook fa-stack-1x"></i> </span></a> <a href="https://twitter.com/@flow_chile" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-twitter fa-stack-1x"></i> </span></a> <a href="https://www.instagram.com/flowpuntocl/" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-instagram fa-stack-1x"></i> </span></a> <a href="http://vimeo.com/flowvideos" target="_blank" class="hvr-grow"> <span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-vimeo fa-stack-1x"></i> </span></a> <a href="https://www.youtube.com/channel/UCIHMLt0pJDoTX19QJWpc5dg?view_as=subscriber" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-youtube-play fa-stack-1x"></i> </span></a>
                <div class="hidden-xs hidden-sm pull-right"><a href="/seguro.php#pci"><img class="img-responsive" alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- / FOOTER --> 

<!-- Modal Contactanos -->
<div class="modal fade" id="modalContactanos" tabindex="-1" role="dialog" aria-labelledby="modalContactanosLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>Contáctanos para mayor información </h2>
                </div>
            </div>
            <div class="modal-body">
                <p> ¿Quieres obtener este servicio? Puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<!-- Modal Pronto -->
<div class="modal fade" id="modalPronto" tabindex="-1" role="dialog" aria-labelledby="modalProntoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>¡Pronto! </h2>
                </div>
            </div>
            <div class="modal-body">
                <p>Estamos trabajando en este servicio, pronto se encontrará disponible. </p>
                <p>Recuerda que puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<!-- The scroll to top feature --> 
<a href="javascript:" id="return-to-top"> <i class="fa fa-chevron-up"> </i></a>	<script src="js/jquery-1.11.3.min.js"></script>
	<script src="js/bootstrap.3.3.7.min.js"></script>
	<script src="js/fancybox/dist/jquery.fancybox.min.js"></script>
	<script>
		$('.panel-cont-claro').on( 'shown.bs.collapse', function ( e ) {
			var $panel = $( this ).closest( '.panel' );
			var div_alto = $( "#mainNav" ).height();
			var div_altoWith = $( "#mainNav" ).outerHeight();
			var div_altoSecond = $( "#secondNavbar" ).height();
			var fromTop = div_alto + div_altoSecond + 5;
			$( 'html,body' ).animate( {
				scrollTop: $panel.offset().top - fromTop
			}, 500 );
		} );
	</script>
	<script>
		$(document).ready(function () {
			$.ajax( {
				type: "get",
				url: "app/services/getFaq.php",
				cache: false,
				dataType: "json",
				async: false,
				success: function (data, status) {
					if (data.result == "success") {
						
						/*Section*/
						var html = "";
						var html2 = "";
						$.each(data.dataSection, function (index, value) {
							html += '<div class="flow-frame hide">';
							html += '	<h3 id="' + value['tag'] + '"><i class="' + value['icon'] + '" aria-hidden="true"></i> ' + value['titulo'] + '</h3>';
							html += '	<div class="panel-group" id="accordion' + value['id'] + '" role="tablist" aria-multiselectable="true" style="text-align:justify;">';
							html += '	</div>';
							html += '</div>';
							
							html2 += '<li class="sub"><a href="javascript:scroll_to_class(' + value['tag'] + ')">' + value['tituloMenu'] + '</a>';
							html2 += '</li>';
						});	
						$("#faqSection").html(html);
						$("#subMenu").html(html2);
						
						/*Details*/
						var htmlArray= new Array();
						var count = 1;
						$.each(data.data, function (index, value) {
							html = '';
							html += '<div class="panel panel-cont-claro">';
							html += '	<a role="button" data-toggle="collapse" data-parent="#accordion'+value['seccion']+'" href="#collapse'+value['id']+'" aria-controls="collapse'+value['id']+'">';
							html += '		<div class="panel-heading" role="tab" id="heading'+value['id']+'">';
							html += '			<h4 class="panel-title">' + count + '. ' + value['titulo'] + '</h4>';
							html += '		</div>';
							html += '	</a>';
							html += '	<div id="collapse'+value['id']+'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading'+value['id']+'">';
							html += '		<div class="table-responsive">';
							html += '			<div class="panel-body">';
							html += '				' + value['contenido'];
							html += '			</div>';
							html += '		</div>';
							html += '	</div>';
							html += '</div>';
							if(typeof (htmlArray[value['seccion']]) === "undefined") {
								htmlArray[value['seccion']] = html;
							} else {
								htmlArray[value['seccion']] += html;
							}
							count++;
						});
						$.each(htmlArray, function (index, value) {
							$("#accordion"+index).html(value);
						});
						$(".flow-frame").removeClass("hide");
					}
				}
			});
		});
	</script>
	<script src="secciones-pagina/footer.js"></script>
</body>
</html>