<!DOCTYPE html>
<html lang="es" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">

<head>
		    
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TTPSNQC');</script>
<!-- End Google Tag Manager -->    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Flow - Plataforma de pagos online - Chile</title>
    <meta name="description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito">
    <meta name="keywords" content="plataforma de pagos, pagos online, pagar, cobrar, pagos en linea, pagos electronicos, ecommerce, tarjetas, credito, debito, redcompra, prepago, webpay, tarjetas de credito, visa, mastercard, magna, american express, sistema de pagos, recaudar, chile, cuotas, ventas online, transbank">
    <meta name="author" content="Flow">
    <meta property="og:title" content="Flow - Plataforma de pagos online - Chile"/>
    <meta property="og:description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito"/>
    <meta property="og:site_name" content="Flow"/>
    <meta property="og:type" content="website"/>
    <meta property="og:image" content="http://www.flow.cl/img/6.png"/>
    <meta property="og:image:width" content="400"/>
    <meta property="og:image:height" content="211"/>
    <meta property="og:image:alt" content="Flow Plataforma de pagos online"/>
    <meta property="og:url" content="http://www.flow.cl/opencart.php"/>
    <link rel="canonical" href="http://www.flow.cl/opencart.php" />
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/img/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/img/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
    <link rel="manifest" href="/img/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="/css/bootstrap.3.3.7.min.css">
    <link rel="stylesheet" href="/css/forms.css">
    <link rel="stylesheet" href="/css/flow.css">
    <link rel="stylesheet" href="/css/menu.css">
    <link rel="stylesheet" href="/css/footer.css?v=20191203">
    <link rel="stylesheet" href="/css/font-awesome.4.7.0.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato|Montserrat">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->
   	<!-- CSS Propio -->
	<link rel="stylesheet" href="/css/colores.css?v=1">
	<link rel="stylesheet" href="/css/interior.css">
	<link rel="stylesheet" type="text/css" href="/js/fancybox/dist/jquery.fancybox.min.css">
	<style>
		#header img {
			width: 49%;
		}
		hr {
			margin-top:0px;
			border-top: 1px solid #EAEAEA;
		}
	</style>
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTPSNQC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><!-- NAVBAR -->
<div id="mainNav" class="navbar yamm navbar-default navbar-fixed-top">
    <div class="container menuSuperior">
        <div class="navbar-header">
            <button type="button" data-toggle="collapse" data-target="#navbar-collapse-2" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a href="index.php" class="navbar-brand"><img src="images/header/logo-flow.svg"></a>
        </div>
        <div id="navbar-collapse-2" class="navbar-collapse collapse collapseHeader">
            <ul class="nav navbar-nav pull-left">
                <li><a href="info.php" class="menu">Conócenos</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu">Recibe pagos<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <!-- Content container to add padding -->
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="cobra-email.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/cobro-email.svg"> Cobra por email</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/carro-compra.svg">En tu carro de compras</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/mall.svg"> En tu propia tienda gratis</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="vende-presencialmente.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/venta-presencial.svg"> Vende presencialmente</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="redes-sociales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/redes-sociales.svg"> En redes sociales</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="soluciones-empresariales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/soluciones-empresariales.svg"> Soluciones empresariales </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="suscripciones.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/forma-recurrente.svg"> Suscripciones</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="web-sistema.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/web-sistema.svg"> En tu web o sistema computacional </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="reembolsos.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/reembolso.svg"> Reembolsos</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu" aria-expanded="false">Información técnica <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg">Integrar plugins de e-commerce</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="/docs/api.html" target="_blank">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica.svg">Documentación API Rest</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg"> Integrar Sumar.cl a tu sitio web</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="/faq.php"class="menu">Ayuda</a>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="http://comunicaciones-flow.cl/blog" target = "_blank" class="menu">Blog</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/register.php" class="menu">Regístrate</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/login.php" class="menu">Ingresa</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="visible-lg"><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default botonMenu">Regístrate</a>
                </li>
                <li class="visible-lg"><a href="app/web/login.php" class="btn btn-default btn-lg btn-flow-inv botonMenu">Ingresa</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- !NAVBAR -->	<div id="secondNavbar" class="navbar navbar-fixed-top second-navbar visible-lg">
		<div class="container">
			<div class="navbar-header pull-left second-nav">
				<ul class="nav navbar-nav">
					<li class="tituloSecond">Extensión para OpenCart 2.2</li>
				</ul>
			</div>
			<ul class="nav navbar-nav navbar-right">
				<li> <a href="javascript: history.go(-1)"><i class="fa fa-arrow-left" aria-hidden="true"></i> Volver</a> </li>
				<li class="divider-vertical"></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Accesos rápidos <i class="caret"></i></a>
					<ul class="dropdown-menu">
						<li class="sub"><a href="javascript:scroll_to_class('#target-0')">Inicio </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-2')">Requisitos </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-3')">Agregar y configurar pesos chilenos como moneda</a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-4')">Descargar e instalar </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-5')">Actualizar extensión de Flow </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-6')">Habilitación de la extensión OpenCart de Flow </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-7')">Configuración del medio de pago Flow </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-ambiente')">Realizar pruebas en plataforma sandbox </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-8')">Opciones avanzadas </a>
						</li>
					</ul>
				</li>
				<li class="divider-vertical"></li>
			</ul>
		</div>
	</div>
	<div id="header" class="header-contenido-1">
		<div class="overlay-header-contenido-celeste-o">
			<div class="container">
				<div class="row" style="margin-top: 2em;">
					<div class="col-xs-12 col-sm-7 col-lg-7">
						<h1 id="target-0" class="titulo-principal-xxl">Extensión para OpenCart 2.2</h1>
						<p class="parrafo-principal-xxl">Recibe pagos online en tu tienda OpenCart mediante Flow.</p>
						<p><a href="opencart.php" class="btn btn-default btn-lg btn-flow-default texto-boton" style="margin-bottom: 5px;" disabled>Opencart 2.2</a> <a href="opencart-23.php" class="btn btn-default btn-lg btn-flow-default texto-boton" style="margin-bottom: 5px;">Opencart 2.3</a> <a href="opencart-3.php" class="btn btn-default btn-lg btn-flow-default texto-boton" style="margin-bottom: 5px;">Opencart 3.0</a>
						</p>
					</div>
					<div class="col-xs-12 col-sm-5 col-lg-5"> <img class="pull-right" src="images/soluciones/opencart.png"> </div>
				</div>
			</div>
		</div>
	</div>
	<div class="container nopadding-movil">
		<div class="seccion fondo-claro">
	<div class="titulo-producto">
		<h2> Integra Flow como sistema de pago </h2>
	</div>
	<p>
		Si tienes una página E-commerce desarrollada con OpenCart, puedes integrar Flow mediante las extensiones y comenzar a operar con pagos online.
	</p>
	<h3>¿No eres parte de Flow?</h3>
	<p>
		Antes de continuar, debes registrarte en Flow y seleccionar la opción <b>"Quiero recibir pagos a través de Flow".</b>
		Si aún no estas registrado puedes hacerlo aquí:
	</p>
	<p>
		<a target="_blank" href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default texto-boton"><img src="images/registrate.svg"> Regístrate</a>
	</p>
</div>		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-2">Requisitos</h2>
			</div>
			<p> Para integrar Flow a tu sitio de E-commerce basado en OpenCart necesitas:</p>
			<ul>
				<li>Estar registrado en Flow como vendedor.</li>
				<li>Obtener el ApiKey y Secret Key desde la sección "Mis Datos &gt; Seguridad" de tu cuenta Flow.</li>
				<li>OpenCart versión 2.2 o inferior.</li>
				<li>Verificar que tu tienda esté visible desde internet.</li>
			</ul>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-3">Agregar y configurar pesos chilenos como moneda</h2>
			</div>
			<p>Para asegurarte que los pagos sean correctamente informados por Flow a tu sitio de E-commerce, es importante que se utilice el peso chileno como moneda. Para agregar dicha moneda debes:</p>
			<ol>
				<li>Entrar a la administración del portal.</li>
				<li>Ir a Sistema &gt; Localización &gt; Monedas.</li>
				<li>Hacer clic en "+" para insertar una nueva moneda.</li>
			</ol>
			<div align="center">
				<figure> <a href="/images/soluciones/opencart/oc2.2-01.jpg" data-fancybox="group-img" data-caption="Agregar moneda"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-01.jpg" alt="Agregar moneda" /> </a>
					<figcaption>Agregar moneda</figcaption>
				</figure>
			</div>
			<p>En dicho formulario debes completar los campos con los siguientes valores:</p>
			<ol>
				<li>Agregar Peso Chileno como título.</li>
				<li>Agregar CLP como código.</li>
				<li>Agregar $ como símbolo a la izquierda.</li>
				<li>Dejar símbolo a derecha en blanco.</li>
				<li>Agregar 0 como decimales.</li>
				<li>Agregar 1.0000 como valor.</li>
				<li>Seleccionar el estado como activo.</li>
				<li>Hacer clic en "Guardar".</li>
			</ol>
			<div align="center">
				<figure> <a href="/images/soluciones/opencart/oc2.2-02.jpg" data-fancybox="group-img" data-caption="Campos de moneda"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-02.jpg" alt="Campos de moneda" /> </a>
					<figcaption>Campos de moneda</figcaption>
				</figure>
			</div>
			<p>Finalmente, para configurar el peso chileno como moneda por defecto realiza lo siguiente:</p>
			<ol>
				<li>Entrar a la administración de OpenCart.</li>
				<li>Ir a Sistema &gt; Configuración.</li>
				<li>Seleccionar la tienda que deseas configurar y hacer clic en "Editar".</li>
			</ol>
			<div align="center">
				<figure> <a href="/images/soluciones/opencart/oc2.2-03.jpg" data-fancybox="group-img" data-caption="Configurar moneda"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-03.jpg" alt="Configurar moneda" /> </a>
					<figcaption>Configurar moneda</figcaption>
				</figure>
			</div>
			<p>En dicho formulario debes completar los campos con los siguientes valores:</p>
			<ol>
				<li>Hacer clic en el tab "Local".</li>
				<li>Seleccionar Chile como país.</li>
				<li>Seleccionar la región donde funcionas.</li>
				<li>En Moneda seleccionar "Peso Chileno" como predeterminada.</li>
				<li>Seleccionar "Si" en Auto Actualización de moneda (divisas).</li>
				<li>Clic en "Grabar".</li>
			</ol>
			<div align="center">
				<figure> <a href="/images/soluciones/opencart/oc2.2-04.jpg" data-fancybox="group-img" data-caption="Campos de configuración"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-04.jpg" alt="Campos de configuración" /> </a>
					<figcaption>Campos de configuración</figcaption>
				</figure>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-4">Descargar e instalar</h2>
			</div>
			<div class="panel-group grupo-contenido" id="accordion" role="tablist" aria-multiselectable="true">
				<div class="panel panel-default panel-contenido">
					<div class="panel-heading encabezado-contenido" role="tab" id="headingOne">
						<h3 class="panel-title titulo-contenido"><a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less-accordion glyphicon glyphicon-minus"></i> Extensión Flow Webpay </a></h3>
					</div>
					<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
						<div class="panel-body cuerpo-contenido">
							<p>Con esta extensión Flow envía la transacción directo a Webpay, sin presentar una página de Flow con los datos de la transacción.</p>
							<p>
								<a href="plugins/opencart/2.2/flow_webpay-1.0.0.ocmod.zip" target="_blank" class="btn btn-default btn-lg btn-flow-inv texto-boton"><img src="/images/download.svg"> Descargar</a>
							</p>
						</div>
					</div>
				</div>

				<div class="panel panel-default panel-contenido">
					<div class="panel-heading encabezado-contenido" role="tab" id="headingTwo">
						<h3 class="panel-title titulo-contenido"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"> <i class="more-less-accordion glyphicon glyphicon-plus"></i> Extensión Flow Servipag </a></h3>
					</div>
					<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
						<div class="panel-body cuerpo-contenido">
							<p>Con esta extensión Flow envía la transacción directo a Servipag, sin presentar una página de Flow con los datos de la transacción.</p>
							<p>
								<a href="plugins/opencart/2.2/flow_servipag-1.0.0.ocmod.zip" target="_blank" class="btn btn-default btn-lg btn-flow-inv texto-boton"><img src="/images/download.svg"> Descargar</a>
							</p>
						</div>
					</div>
				</div>

				<div class="panel panel-default panel-contenido">
					<div class="panel-heading encabezado-contenido" role="tab" id="headingThree">
						<h3 class="panel-title titulo-contenido"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree"> <i class="more-less-accordion glyphicon glyphicon-plus"></i> Extensión Flow Multicaja </a></h3>
					</div>
					<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
						<div class="panel-body cuerpo-contenido">
							<p>Con esta extensión Flow envía la transacción directo a Multicaja, sin presentar una página de Flow con los datos de la transacción.</p>
							<p>
								<a href="plugins/opencart/2.2/flow_multicaja-1.0.0.ocmod.zip" target="_blank" class="btn btn-default btn-lg btn-flow-inv texto-boton"><img src="/images/download.svg"> Descargar</a>
							</p>
						</div>
					</div>
				</div>
				
				<div class="panel panel-default panel-contenido">
					<div class="panel-heading encabezado-contenido" role="tab" id="headingFour">
						<h3 class="panel-title titulo-contenido"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour"> <i class="more-less-accordion glyphicon glyphicon-plus"></i> Extensión Flow Onepay </a></h3>
					</div>
					<div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
						<div class="panel-body cuerpo-contenido">
							<p>Con esta extensión Flow envía la transacción directo a Onepay, sin presentar una página de Flow con los datos de la transacción.</p>
							<p>
								<a href="plugins/opencart/2.2/flow_onepay-1.0.0.ocmod.zip" target="_blank" class="btn btn-default btn-lg btn-flow-inv texto-boton"><img src="/images/download.svg"> Descargar</a>
							</p>
						</div>
					</div>
				</div>
				
				<div class="panel panel-default panel-contenido">
					<div class="panel-heading encabezado-contenido" role="tab" id="headingFive">
						<h3 class="panel-title titulo-contenido"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive"> <i class="more-less-accordion glyphicon glyphicon-plus"></i> Extensión Pasarela Flow </a></h3>
					</div>
					<div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
						<div class="panel-body cuerpo-contenido">
							<p>Con esta extensión antes de enviar la transacción a un medio de pago, se presenta una página de Flow con los datos de la transacción. Además, en dicha página se muestran los medios de pago habilitados por el vendedor, permitiendo al pagador elegir el deseado.</p>
							 <p>
								<a href="plugins/opencart/2.2/flow-1.0.0.ocmod.zip" target="_blank" class="btn btn-default btn-lg btn-flow-inv texto-boton"><img src="/images/download.svg"> Descargar</a>
							</p>
						</div>
					</div>
				</div>
			</div>
			<br>
			<h3>Instalar mediante instalador de extensiones de Opencart</h3>
			<hr>
			<p>
				Para instalar la extensión desde el instalador incorporado en Opencart debes:
			</p>
			<ol>
				<li>
					Entrar a la administración de OpenCart.
				</li>
				<li>
					Ir a Extensiones > Instalador de extensiones.
				</li>
				<li>
					Haz clic en "Upload" para ubicar y seleccionar el archivo de la extensión que deseas instalar (las extensiones instalables de Opencart incluyen <b>ocmod.zip</b> en su nombre de archivo).
				</li>
				<li>
					Haz clic en "Continuar" para finalizar la instalación.
				</li>
			</ol>
			<div align="center">
				<figure>
					<a href="/images/soluciones/opencart/oc2.2-05.jpg" data-fancybox="group-img" data-caption="Instalar extensión"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-05.jpg" alt="Instalar extensión" /> </a>
					<figcaption>
						Instalar extensión
					</figcaption>
				</figure>
			</div>
			<p>
				Antes de utilizar el instalador de extensiones en Opencart, debes considerar tener configurado el servidor FTP, para lo cual debes:
			</p>
			<ol>
				<li>
					Entrar a la administración de OpenCart.
				</li>
				<li>
					Ir a Sistema &gt; Configuración.
				</li>
				<li>
					Seleccionar la tienda que deseas configurar y hacer clic en "Editar".
				</li>
				<li>
					Hacer clic en el tab "FTP".
				</li>
				<li>
					Ingresar datos de host, puerto, usuario, contraseña, el directorio de la instalación de Opencart y activar el FTP.
				</li>
				<li>
					Hacer clic en "Grabar".
				</li>
			</ol>
			<div align="center">
				<figure>
					<a href="/images/soluciones/opencart/oc2.2-06.jpg" data-fancybox="group-img" data-caption="Configurar FTP"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-06.jpg" alt="Configurar FTP" /> </a>
					<figcaption>
						Configurar FTP
					</figcaption>
				</figure>
			</div>
			<p>
				Además debes tener permisos de escritura para los siguientes directorios:
			</p>
			<ul>
				<li>
					/admin/controller/extension/
				</li>
				<li>
					/admin/language/
				</li>
				<li>
					/admin/model/extension/
				</li>
				<li>
					/admin/view/image/
				</li>
				<li>
					/admin/view/javascript/
				</li>
				<li>
					/admin/view/stylesheet/
				</li>
				<li>
					/admin/view/template/extension/
				</li>
				<li>
					/catalog/controller/extension/
				</li>
				<li>
					/catalog/language/
				</li>
				<li>
					/catalog/model/extension/
				</li>
				<li>
					/catalog/view/javascript/
				</li>
				<li>
					/catalog/view/theme/
				</li>
				<li>
					/system/config/
				</li>
				<li>
					/system/library/
				</li>
				<li>
					/image/catalog/
				</li>
			</ul>
			<br>
			<h3>Copiar los archivos directamente al FTP</h3>
			<hr>
			<p>
				Para copiar los archivos directamente al FTP, debes descomprimir el archivo zip y subir las carpetas y archivos contenidos en la carpeta /upload/.
				Dicho contenido debe ser copiado en las mismas carpetas admin y catalog de tu OpenCart.
			</p>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-5">Actualizar extensión de Flow</h2>
			</div>
			<p>
				Si ya posees una versión de la extensión de Flow instalada en tu OpenCart y deseas actualizarla, debes reemplazar los archivos antiguos por los archivos actualizados.
				Para ello basta arrastrar las carpetas admin y catalog, obtenidas al descomprimir la nueva versión de la extensión, en las mismas carpetas de OpenCart. Es importante que todos los archivos sean reemplazados.
			</p>
			<p>
				Luego, debes configurar la extensión tal como se muestra en el paso Configurar la extensión de Flow. 
			</p>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-6">Habilitación de la extensión OpenCart de Flow</h2>
			</div>
			<p>Para habilitar cada extensión sigue las siguientes instrucciones:</p>
			<ol>
				<li>En el menú de administración de OpenCart selecciona Extensiones &gt; Pagos.</li>
				<li>Podrás encontrar las extensiones Flow de los medios de pago.</li>
				<li>Instala las extensiones que desees utilizar, haciendo clic en "Instalar".</li>
			</ol>
			<div align="center">
				<figure> <a href="/images/soluciones/opencart/oc2.2-07.jpg" data-fancybox="group-img" data-caption="Instalar módulo Flow"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-07.jpg" alt="Instalar módulo Flow" /> </a>
					<figcaption>Instalar módulo Flow</figcaption>
				</figure>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-7">Configuración del medio de pago Flow</h2>
			</div>
			<p>Para cada extensión de Flow instalada, debes hacer click en "Editar" y configurar los siguientes campos:</p>
			<div align="center">
				<figure> <a href="/images/soluciones/opencart/oc2.2-08.jpg" data-fancybox="group-img" data-caption="Configurar forma de pago"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-08.jpg" alt="Configurar forma de pago" /> </a>
					<figcaption>Configurar forma de pago</figcaption>
				</figure>
			</div>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Campo</th>
							<th>Descripción</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Plataforma de Flow</td>
							<td>
								Selecciona si utilizarás la plataforma de producción o la plataforma sandbox de Flow:
								<ul>
									<li>
										<strong>Plataforma de producción:</strong> Se encuentra disponible en <a href="https://www.flow.cl" target="_blank">www.flow.cl</a> y corresponde al sitio oficial, el cual debes utilizar para recibir tus pagos.
									</li>
									<li>
										<strong>Plataforma sandbox:</strong> Se encuentra disponible en <a href="https://sandbox.flow.cl" target="_blank">sandbox.flow.cl</a> y corresponde al sitio de pruebas, 
										donde podrás realizar pagos de test para verificar el correcto funcionamiento de la extensión.
									</li>
							</td>
						</tr>
						<tr>
							<td>Nombre medio de pago</td>
							<td>
								Ingresa el nombre que se mostrará a las personas cuando paguen en tu tienda virtual, por ejemplo:
								<ul>
									<li><strong>Flow Webpay:</strong> Pagar con tarjetas de crédito y débito bancarias.</li>
									<li><strong>Flow Servipag</strong>: Pagar con bancos, tarjetas CMR, Ripley, Cencosud y sucursales Servipag.</li>
									<li><strong>Flow Multicaja:</strong> Pagar en efectivo en locales Multicaja.</li>
									<li><strong>Flow Onepay:</strong> Pagar con tarjetas de crédito.</li>
									<li><strong>Flow:</strong> Pagar mediante Flow a través de Webpay, Servipag, Multicaja, Onepay y Cryptocompra.</li>
								</ul>
							</td>
						</tr>
						<tr>
							<td>Api Key</td>
							<td>
								Ingresa el Api Key asociado a tu cuenta de Flow:
								<ul>
									<li>
										<strong>Si estás utilizando la plataforma de producción:</strong>
										Obtén tu Api Key desde la sección "Mis Datos > Seguridad" en <a href="https://www.flow.cl/app/web/misDatos.php" target="_blank">www.flow.cl.</a>
									</li>
									<li>
										<strong>Si estás utilizando la plataforma sandbox:</strong>
										Obtén tu Api Key desde la sección "Mis Datos > Seguridad" en <a href="https://sandbox.flow.cl/app/web/misDatos.php" target="_blank">sandbox.flow.cl.</a>
									</li>
								</ul>
							</td>
						</tr>
						<tr>
						<td>Secret Key</td>
							<td>
								Ingresa el Secret Key asociado a tu cuenta de Flow:
								<ul>
									<li>
										<strong>Si estás utilizando la plataforma de producción:</strong>
										Obtén tu Secret Key desde la sección "Mis Datos > Seguridad" en <a href="https://www.flow.cl/app/web/misDatos.php" target="_blank">www.flow.cl.</a>
									</li>
									<li>
										<strong>Si estás utilizando la plataforma sandbox:</strong>
										Obtén tu Secret Key desde la sección "Mis Datos > Seguridad" en <a href="https://sandbox.flow.cl/app/web/misDatos.php" target="_blank">sandbox.flow.cl.</a>
									</li>
								</ul>
							</td>
						</tr>
						<tr>
							<td>Url de retorno</td>
							<td>Sólo aplica a la extensión de Servipag, Multicaja y Pasarela Flow. Corresponde a la página donde volverá el cliente una vez que generó un cupón de pago. Recomendamos que dicha url sea la página principal de tu tienda.</td>
						</tr>
						<tr>
							<td>Estado de pago exitoso</td>
							<td>Selecciona "Processed".</td>
						</tr>
						<tr>
							<td>Estado de pago Fallido </td>
							<td>Selecciona "Failed".</td>
						</tr>
						<tr>
							<td>Zona geográfica</td>
							<td>Selecciona "Todas las zonas".</td>
						</tr>
						<tr>
							<td>Estado</td>
							<td>Selecciona "Habilitado".</td>
						</tr>
						<tr>
							<td>Orden</td>
							<td> Corresponde al orden en que se mostrarán los medios de pago. Puedes utilizar el valor que desees.</td>
						</tr>
						<tr>
							<td>Clic en "Guardar"</td>
							<td>Debes hacer clic en "Guardar" para confirmar tu configuración.</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		
<div class="seccion fondo-claro">
	<div class="titulo-producto">
		<h2 id="target-ambiente">Realizar pruebas en plataforma sandbox</h2>
	</div>
	<p>
		Para utilizar la plataforma sandbox debes:
		<ul>
			<li>
				Registrarte previamente en <a href="https://sandbox.flow.cl" target="_blank">sandbox.flow.cl</a>.
			</li>
			<li>
				Configurar la extensión utilizando la plataforma sandbox. Para ello debes revisar el punto anterior.
			</li>
			<li>
				Finalmente, podrás simular un pago mediante Webpay Plus con las siguientes tarjetas de prueba. Recuerda que el monto mínimo a pagar son $350 CLP.
			</li>
			<li>
				Una vez concretadas las pruebas, debes configurar  la extensión utilizando la plataforma de producción. Para ello debes revisar el punto anterior.
			</li>
		</ul>
	</p>
	<br>
	<h3>Pago exitoso</h3>
	<hr style="margin-top:0px;">
	<div class="table-responsive">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Dato</th>
					<th>Valor</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>N° Tarjeta de Crédito</td>
					<td>4051885600446623</td>
				</tr>
				<tr>
					<td>Año de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>Mes de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>CVV</td>
					<td>123</td>
				</tr>
				<tr>
					<td><strong>En la simulación del banco usar:</strong>
					</td>
					<td></td>
				</tr>
				<tr>
					<td>Rut</td>
					<td>11.111.111-1</td>
				</tr>
				<tr>
					<td>Clave</td>
					<td>123</td>
				</tr>
			</tbody>
		</table>
	</div>
	
	<br>
	<h3>Pago rechazado</h3>
	<hr>
	<div class="table-responsive">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Dato</th>
					<th>Valor</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>N° Tarjeta de Crédito</td>
					<td>5186059559590568</td>
				</tr>
				<tr>
					<td>Año de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>Mes de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>CVV</td>
					<td>123</td>
				</tr>
				<tr>
					<td><strong>En la simulación del banco usar:</strong>
					</td>
					<td></td>
				</tr>
				<tr>
					<td>Rut</td>
					<td>11.111.111-1</td>
				</tr>
				<tr>
					<td>Clave</td>
					<td>123</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-8">Opciones avanzadas</h2>
			</div>
			<p> A continuación se muestran opciones adicionales para personalizar la configuración de la extensión. Estas opciones requieren cierto nivel de conocimiento sobre HTML y programación.</p>
			
			<br>
			<h3>Agregar imagen al medio de pago</h3>
			<hr>
			<p>Para agregar una imagen personalizada al medio de pago, debes seguir las siguientes instrucciones:</p>
			<div class="table-responsive">
				<ol>
					<li>Abrir los siguientes archivos:</li>
					<ul>
						<li>catalog/model/payment/flow_Webpay.php para Flow Webpay.</li>
						<li>catalog/model/payment/flow_servipag.php para Flow Servipag.</li>
						<li>catalog/model/payment/flow_multicaja.php para Flow Multicaja.</li>
						<li>catalog/model/payment/flow_Onepay.php para Flow Onepay.</li>
						<li>catalog/model/payment/flow.php para pasarela de Flow.</li>
					</ul>
					<li>Añadir el link de la imagen deseada en la línea 9:
						<ul>
							<li> <i>'title'=&gt; '&lt;img src="https://www.flow.cl/img/logos/webpay.png" style="vertical-align:middle; width: 100px;" /&gt; '.$this-&gt;language-&gt;get('text_title'),</i> </li>
							<li> <i>'title'=&gt; '&lt;img src="https://www.flow.cl/img/logos/servipag.png" style="vertical-align:middle; width: 100px;" /&gt; '.$this-&gt;language-&gt;get('text_title'),</i> </li>
							<li> <i>'title'=&gt; '&lt;img src="https://www.flow.cl/img/logos/multicaja.png" style="vertical-align:middle; width: 100px;" /&gt; '.$this-&gt;language-&gt;get('text_title'),</i> </li>
							<li> <i>'title'=&gt; '&lt;img src="https://www.flow.cl/img/logos/onepay.png" style="vertical-align:middle; width: 100px;" /&gt; '.$this-&gt;language-&gt;get('text_title'),</i> </li>
							<li> <i>'title'=&gt; '&lt;img src="https://www.flow.cl/img/logos/flow.png" style="vertical-align:middle; width: 100px;" /&gt; '.$this-&gt;language-&gt;get('text_title'),</i> </li>
						</ul>
					</li>
					<li>El valor del atributo src permite insertar la URL de la imagen deseada, mientras que el valor del atributo width permite ajustar el ancho de la imagen.</li>
					<li>Finalmente, se deben guardar los cambios y revisar que la imagen se muestre correctamente.</li>
				</ol>
			</div>
			<div align="center">
				<figure> <a href="/images/soluciones/opencart/oc2.2-09.jpg" data-fancybox="group-img" data-caption="Vista opciones Avanzadas"> <img class="img-responsive img-rounded img-thumbnail" src="/images/soluciones/opencart/oc2.2-09.jpg" alt="Vista opciones Avanzadas" /> </a>
					<figcaption>Vista opciones avanzadas</figcaption>
				</figure>
			</div>
			
			<br>
			<h3>Tengo un error de integración</h3>
			<hr>
			<p>
				Para conocer el error de integración debes acceder al archivo de log disponible en tu FTP. Este archivo se encuentra disponible en las siguientes carpetas:
			</p>
			<ul>
				<li><b>Webpay:</b> system/storage/logs/flow_Webpay.log</li>
				<li><b>Servipag:</b> system/storage/logs/flow_servipag.log</li>
				<li><b>Multicaja:</b> system/storage/logs/flow_multicaja.log</li>
				<li><b>Onepay:</b> system/storage/logs/flow_Onepay.log</li>
				<li><b>Pasarela Flow:</b> system/storage/logs/flow_flow.log</li>
			</ul>
			<p>
				Si no conoces como solucionar el problema de integración, puedes contactarnos al correo <b><a href="mailto:soporte@flow.cl">soporte@flow.cl</a></b>, indicándonos el error, la plataforma de Flow que estás utilizando y tu Api Key.
			</p>
		</div>
	</div>
	<!-- FOOTER -->
<div id="footer" class="footer">
    <div class="container visible-lg visible-md">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6">
                <h5>Preguntas frecuentes</h5>
                <ul class="unstyled">
                    <li><a href="faq.php#pagar">Pagar con Flow</a>
                    </li>
                    <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                    </li>
                    <li><a href="faq.php#ayuda">Ayuda técnica</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Tarifas y condiciones</h5>
                    <ul class="unstyled">
                        <li><a href="tarifas.php">Tarifas vigentes</a>
                        </li>
                        <li><a href="terminos.php">Términos &amp; condiciones</a>
                        </li>
                        <li><a href="privacidad.php">Política de privacidad</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Contacto</h5>
                    <ul class="unstyled">
                        <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                        </li>
                        <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 cajaLogos">
                <h5>En Flow recibes pagos con: </h5>
                <ul class="unstyled">
                    <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container hidden-lg hidden-md">
        <div class="panel-default" id="accordionFooter" role="tablist" aria-multiselectable="true">
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter1">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter1" aria-expanded="true" aria-controls="collapseFooter1"> <i class="more-less fa fa-chevron-down"></i> Preguntas frecuentes </a> </h4>
                </div>
                <div id="collapseFooter1" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter1">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="faq.php#pagar">Pagar con Flow</a>
                            </li>
                            <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                            </li>
                            <li><a href="faq.php#ayuda">Ayuda técnica</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter2">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter2" aria-expanded="true" aria-controls="collapseFooter2"> <i class="more-less fa fa-chevron-down"></i> Tarifas y condiciones </a> </h4>
                </div>
                <div id="collapseFooter2" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter2">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tarifas.php">Tarifas vigentes</a>
                            </li>
                            <li><a href="terminos.php">Términos &amp; condiciones</a>
                            </li>
                            <li><a href="privacidad.php">Política de privacidad</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter3">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter3" aria-expanded="true" aria-controls="collapseFooter3"> <i class="more-less fa fa-chevron-down"></i> Contacto </a> </h4>
                </div>
                <div id="collapseFooter3" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter3">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                            </li>
                            <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter4">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter4" aria-expanded="true" aria-controls="collapseFooter4"> <i class="more-less fa fa-chevron-down"></i> En Flow recibes pagos con: </a> </h4>
                </div>
                <div id="collapseFooter4" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter4">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter5">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter5" aria-expanded="true" aria-controls="collapseFooter5"> <i class="more-less fa fa-chevron-down"></i> Seguridad </a> </h4>
                </div>
                <div id="collapseFooter5" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter5">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/seguro.php#sitelock"><img alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a> </li>
                            <li class="logosMediosPagos"> <a href="/seguro.php#pci"><img alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="socialFooter" class="social-footer" align="center">
    <div class="container">
        <div class="row">
            <div class="col-md-12"> 
                <div class="hidden-xs hidden-sm pull-left"><a href="/seguro.php#sitelock"><img class="img-responsive" alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a>
                </div>
                <a href="http://www.facebook.com/flow.cl" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-facebook fa-stack-1x"></i> </span></a> <a href="https://twitter.com/@flow_chile" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-twitter fa-stack-1x"></i> </span></a> <a href="https://www.instagram.com/flowpuntocl/" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-instagram fa-stack-1x"></i> </span></a> <a href="http://vimeo.com/flowvideos" target="_blank" class="hvr-grow"> <span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-vimeo fa-stack-1x"></i> </span></a> <a href="https://www.youtube.com/channel/UCIHMLt0pJDoTX19QJWpc5dg?view_as=subscriber" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-youtube-play fa-stack-1x"></i> </span></a>
                <div class="hidden-xs hidden-sm pull-right"><a href="/seguro.php#pci"><img class="img-responsive" alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- / FOOTER --> 

<!-- Modal Contactanos -->
<div class="modal fade" id="modalContactanos" tabindex="-1" role="dialog" aria-labelledby="modalContactanosLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>Contáctanos para mayor información </h2>
                </div>
            </div>
            <div class="modal-body">
                <p> ¿Quieres obtener este servicio? Puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<!-- Modal Pronto -->
<div class="modal fade" id="modalPronto" tabindex="-1" role="dialog" aria-labelledby="modalProntoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>¡Pronto! </h2>
                </div>
            </div>
            <div class="modal-body">
                <p>Estamos trabajando en este servicio, pronto se encontrará disponible. </p>
                <p>Recuerda que puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<!-- The scroll to top feature --> 
<a href="javascript:" id="return-to-top"> <i class="fa fa-chevron-up"> </i></a>	<!-- JS -->
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/fancybox/dist/jquery.fancybox.min.js"></script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.3.3.7.min.js"></script>
	<!-- JS  -->
	<script src="secciones-pagina/footer.js"></script>
	<script>
		function toggleIcon(e) {
			$(e.target).prev('.panel-heading').find(".more-less-accordion").toggleClass('glyphicon-plus glyphicon-minus');
		}
		$('.panel-group').on('hidden.bs.collapse', toggleIcon);
		$('.panel-group').on('shown.bs.collapse', toggleIcon);
	</script>
</body>

</html>