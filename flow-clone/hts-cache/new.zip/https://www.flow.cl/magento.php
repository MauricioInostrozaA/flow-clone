<!DOCTYPE html>
<html lang="es" xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">

<head>
	        
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TTPSNQC');</script>
<!-- End Google Tag Manager -->    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Flow - Plataforma de pagos online - Chile</title>
    <meta name="description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito">
    <meta name="keywords" content="plataforma de pagos, pagos online, pagar, cobrar, pagos en linea, pagos electronicos, ecommerce, tarjetas, credito, debito, redcompra, prepago, webpay, tarjetas de credito, visa, mastercard, magna, american express, sistema de pagos, recaudar, chile, cuotas, ventas online, transbank">
    <meta name="author" content="Flow">
    <meta property="og:title" content="Flow - Plataforma de pagos online - Chile"/>
    <meta property="og:description" content="Flow es una plataforma de pagos online que te permite pagar y recibir pagos de cualquier persona usando tarjetas de credito o debito"/>
    <meta property="og:site_name" content="Flow"/>
    <meta property="og:type" content="website"/>
    <meta property="og:image" content="http://www.flow.cl/img/6.png"/>
    <meta property="og:image:width" content="400"/>
    <meta property="og:image:height" content="211"/>
    <meta property="og:image:alt" content="Flow Plataforma de pagos online"/>
    <meta property="og:url" content="http://www.flow.cl/magento.php"/>
    <link rel="canonical" href="http://www.flow.cl/magento.php" />
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" sizes="57x57" href="/img/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/img/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
    <link rel="manifest" href="/img/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="/css/bootstrap.3.3.7.min.css">
    <link rel="stylesheet" href="/css/forms.css">
    <link rel="stylesheet" href="/css/flow.css">
    <link rel="stylesheet" href="/css/menu.css">
    <link rel="stylesheet" href="/css/footer.css?v=20191203">
    <link rel="stylesheet" href="/css/font-awesome.4.7.0.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato|Montserrat">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->
       <!-- CSS Propio -->
    <link rel="stylesheet" href="/css/colores.css">
    <link rel="stylesheet" href="/css/interior.css">
    <link rel="stylesheet" type="text/css" href="/js/fancybox/dist/jquery.fancybox.min.css">
	<style>
		#header img {
			width: 53%;
		}
	</style>
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TTPSNQC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><!-- NAVBAR -->
<div id="mainNav" class="navbar yamm navbar-default navbar-fixed-top">
    <div class="container menuSuperior">
        <div class="navbar-header">
            <button type="button" data-toggle="collapse" data-target="#navbar-collapse-2" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <a href="index.php" class="navbar-brand"><img src="images/header/logo-flow.svg"></a>
        </div>
        <div id="navbar-collapse-2" class="navbar-collapse collapse collapseHeader">
            <ul class="nav navbar-nav pull-left">
                <li><a href="info.php" class="menu">Conócenos</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu">Recibe pagos<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <!-- Content container to add padding -->
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="cobra-email.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/cobro-email.svg"> Cobra por email</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/carro-compra.svg">En tu carro de compras</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/mall.svg"> En tu propia tienda gratis</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="vende-presencialmente.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/venta-presencial.svg"> Vende presencialmente</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="redes-sociales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/redes-sociales.svg"> En redes sociales</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="soluciones-empresariales.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/soluciones-empresariales.svg"> Soluciones empresariales </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-3 col-lg-4 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="suscripciones.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/forma-recurrente.svg"> Suscripciones</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="web-sistema.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/web-sistema.svg"> En tu web o sistema computacional </div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="reembolsos.php">
                                                <div><img class="imagenMenu pull-left hidden-xs" src="images/iconos/svg/reembolso.svg"> Reembolsos</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle menu" aria-expanded="false">Información técnica <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <div class="yamm-content">
                                <div class="row">
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="carro-compras.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg">Integrar plugins de e-commerce</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                        <li class="opcionMenu">
                                            <a href="/docs/api.html" target="_blank">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica.svg">Documentación API Rest</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso hidden-lg">
                                    </ul>
                                    <ul class="col-sm-6 list-unstyled">
                                        <li class="opcionMenu">
                                            <a href="tienda-gratis.php">
                                                <div><img class="bullet pull-left hidden-xs" src="images/iconos/svg/info-tecnica2.svg"> Integrar Sumar.cl a tu sitio web</div>
                                            </a>
                                        </li>
                                        <hr class="barra-calipso">
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="/faq.php"class="menu">Ayuda</a>
                </li>
				<li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
				<li><a href="http://comunicaciones-flow.cl/blog" target = "_blank" class="menu">Blog</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/register.php" class="menu">Regístrate</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
                <li class="visible-xs visible-sm visible-md"><a href="app/web/login.php" class="menu">Ingresa</a>
                </li>
                <li class="hidden-lg">
                    <hr class="barra-calipso">
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="visible-lg"><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default botonMenu">Regístrate</a>
                </li>
                <li class="visible-lg"><a href="app/web/login.php" class="btn btn-default btn-lg btn-flow-inv botonMenu">Ingresa</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- !NAVBAR -->	<div id="secondNavbar" class="navbar navbar-fixed-top second-navbar visible-lg">
		<div class="container">
			<div class="navbar-header pull-left second-nav">
				<ul class="nav navbar-nav">
					<li class="tituloSecond">Extensión para Magento</li>
				</ul>
			</div>
			<ul class="nav navbar-nav navbar-right">
				<li> <a href="javascript: history.go(-1)"><i class="fa fa-arrow-left" aria-hidden="true"></i> Volver</a> </li>
				<li class="divider-vertical"></li>
			</ul>
			<ul class="nav navbar-nav navbar-right">
				<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Accesos rápidos <i class="caret"></i></a>
					<ul class="dropdown-menu">
						<li class="sub"><a href="javascript:scroll_to_class('#target-0')">Inicio </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-1')">Modelo de Integración </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-2')">Requisitos </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-3')">Descargar e instalar </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-4')">Actualizar extensión de Flow </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-5')">Configuración del medio de pago Flow </a>
						</li>
						<li class="sub"><a href="javascript:scroll_to_class('#target-ambiente')">Validar configuración </a>
						</li>
					</ul>
				</li>
				<li class="divider-vertical"></li>
			</ul>
		</div>
	</div>
	<div id="header" class="header-contenido-1">
		<div class="overlay-header-contenido-celeste-o">
			<div class="container">
				<div class="row" style="margin-top: 2em;">
					<div class="col-xs-12 col-sm-7 col-lg-7">
						<h1 id="target-0" class="titulo-principal-xxl">Extensión para Magento</h1>
						<p class="parrafo-principal-xxl">Recibe pagos online en tu tienda Magento mediante Flow.</p>
					</div>
					<div class="col-xs-12 col-sm-5 col-lg-5"> <img class="pull-right" src="images/soluciones/magento.png"> </div>
				</div>
			</div>
		</div>
	</div>
	<div class="container nopadding-movil">
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2> Integra Flow como sistema de pago </h2>
			</div>
			<p>Si tienes una página ecommerce desarrollada con Magento, puedes integrar Flow mediante las extensiones y comenzar a operar con pagos online.</p>
			<h3>¿No eres parte de Flow?</h3>
			<p>	
				Antes de continuar debes registrarte en Flow y seleccionar la opción <b>Deseo utilizar Flow para recibir pagos.</b>
				Si aún no estas registrado puedes hacerlo aquí:
			</p>
			<p><a href="app/web/register.php" class="btn btn-default btn-lg btn-flow-default texto-boton"><img src="images/registrate.svg"> Regístrate</a>
			</p>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-1">Modelo de Integración</h2>
			</div>
			<p>Toda la comunicación entre el comercio y Flow viaja firmada electrónicamente con certificados digitales. Las firmas digitales son verificadas en cada punto de comunicación, asegurando la confiabilidad entre el emisor y el receptor. </p>
			<p>A continuación te explicamos los dos modelos de integración con Flow el indirecto y directo.</p>
			<h3>Modo indirecto</h3>
			<p>Con este modo de integración, antes de enviar la transacción a Webpay, Servipag o Multicaja, se presenta una página de Flow con los datos de la transacción. Además, en dicha página se muestran los medios de pago habilitados por el vendedor, permitiendo al pagador elegir el deseado. </p>
			<div align="center">
				<figure> <a href="images/soluciones/api03.png" data-fancybox="group" data-caption="Modo indirecto"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/api03.png" alt="Modo indirecto" /> </a>
					<figcaption>Método de integración indirecto</figcaption>
				</figure>
			</div>
			<h4>Descripción de acciones</h4>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>N°</th>
							<th>Descripción</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>El comercio, utilizando el Kit, envía a Flow una Orden de Pago firmada electrónicamente. </td>
						</tr>
						<tr>
							<td>2</td>
							<td>Flow recibe la Orden y verifica que provenga de un comercio registrado. En este paso presenta una página para que el pagador confirme la orden y seleccione el medio de pago deseado: Webpay, Servipag o Multicaja. </td>
						</tr>
						<tr>
							<td>3</td>
							<td>Flow deriva al pagador a la página del medio de pago (Webpay, Servipag o Multicaja) seleccionado.</td>
						</tr>
						<tr>
							<td>4</td>
							<td>El medio de pago envía a Flow el resultado de la transacción y solicita confirmarla. </td>
						</tr>
						<tr>
							<td>5</td>
							<td>Flow envía el resultado del pago a la página de confirmación del comercio.</td>
						</tr>
						<tr>
							<td>6</td>
							<td>El comercio recibe la confirmación del pago. La página del comercio tiene 15 segundos para responder la recepción de la confirmación. <em>Si su página de confirmación no responde en ese tiempo y la transacción había sido aprobada por el medio de pago, la transacción se dará por aprobada. </em>
							</td>
						</tr>
						<tr>
							<td>7</td>
							<td>Flow envía al medio de pago la confirmación de la transacción.</td>
						</tr>
						<tr>
							<td>8</td>
							<td>Si el pago es exitoso, Flow deriva el control a la página de éxito del comercio. Además, se envía un email notificado del pago al vendedor y al pagador.</td>
						</tr>
						<tr>
							<td>9</td>
							<td>Si el pago es rechazado, Flow despliega su página de fracaso. </td>
						</tr>
						<tr>
							<td>10</td>
							<td>Desde la página de fracaso de Flow, si el cliente hace click en el botón (Volver al comercio) se invoca la página de fracaso del comercio. </td>
						</tr>
					</tbody>
				</table>
			</div>
			<h3>Modo directo</h3>
			<p>Con este modo de integración Flow envía la transacción directo a Webpay, Servipag o Multicaja según corresponda, sin presentar una página de Flow con los datos de la transacción. </p>
			<div align="center">
				<figure> <a href="images/soluciones/api04.png" data-fancybox="group" data-caption="Modo directo"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/api04.png" alt="Modo directo" /> </a>
					<figcaption>Método de integración directo</figcaption>
				</figure>
			</div>
			<h4>Descripción de acciones</h4>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>N°</th>
							<th>Descripción</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>1</td>
							<td>El comercio utilizando el Kit, envía a Flow una Orden de Pago firmada electrónicamente. </td>
						</tr>
						<tr>
							<td>2</td>
							<td>Flow deriva al pagador a la página del medio de pago (Webpay, Servipag o Multicaja) informado desde el Kit. </td>
						</tr>
						<tr>
							<td>3</td>
							<td>El medio de pago envía a Flow el resultado de la transacción y solicita confirmarla. </td>
						</tr>
						<tr>
							<td>4</td>
							<td>Flow envía el resultado del pago a la página de confirmación del comercio. </td>
						</tr>
						<tr>
							<td>5</td>
							<td>El comercio recibe la confirmación del pago. La página del comercio tiene 15 segundos para responder la recepción de la confirmación. <em>Si su página de confirmación no responde en ese tiempo y la transacción había sido aprobada por el medio de pago, la transacción se dará por aprobada.</em>
							</td>
						</tr>
						<tr>
							<td>6</td>
							<td>Flow envía al medio de pago la confirmación de la transacción. </td>
						</tr>
						<tr>
							<td>7</td>
							<td>Si el pago es exitoso Flow deriva el control a la página de éxito del comercio. Además, se envía un email notificado del pago al vendedor y al pagador.</td>
						</tr>
						<tr>
							<td>8</td>
							<td>Si el pago es rechazado Flow despliega su página de fracaso. </td>
						</tr>
						<tr>
							<td>9</td>
							<td>Desde la página de fracaso de Flow si el cliente hace clic en el botón (Volver al comercio) se invoca la página de fracaso del comercio. </td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-2">Requisitos</h2>
			</div>
			<p> Para integrar a Flow tu sitio de E-commerce basado en Magento necesitas:</p>
			<ul>
				<li>Estar registrado en Flow como vendedor</li>
				<li>Descargar el Certificado digital desde "Mis Datos"</li>
				<li>Contar con Magento 1.9 o superior</li>
				<li>Asegurarse que su tienda está visible desde internet</li>
			</ul>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-3">Descargar e instalar</h2>
			</div>
			<h3>Extensión Flow WebPay y Servipag</h3>
			<p><a href="https://www.flow.cl/plugins/FlowPayment-1.0.1.tgz" class="btn btn-default btn-lg btn-flow-inv texto-boton"><img src="images/download.svg"> Descargar</a>
			</p>
			<h3>Extensión Magento Flow MultiCaja</h3>
			<p> <strong>Pronto!</strong> </p>
			<p>Accede al panel de administración de Magento e ingresa a System -&gt; Magento Connect -&gt; Magento Connect Manager. A continuación debes subir la extensión de Flow en el apartado <strong>Direct package file upload</strong>.</p>
			<div align="center">
				<figure> <a href="images/soluciones/magento01.png" data-fancybox="group-img" data-caption="Magento Extensiones"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/magento01.png" alt="Magento Extensiones" /> </a>
					<figcaption>Magento Extensiones</figcaption>
				</figure>
			</div>
			<p>Al cargarse correctamente la extensión, aparecerá en la lista inferior de dicha página</p>
			<div align="center">
				<figure> <a href="images/soluciones/magento02.png" data-fancybox="group-img" data-caption="Cargar extensión"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/magento02.png" alt="Cargar extensión" /> </a>
					<figcaption>Cargar extensión</figcaption>
				</figure>
			</div>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-4">Actualizar extensión de Flow</h2>
			</div>
			<p> Si ya posees una versión de alguno de las extensiones de Flow instalada en tu Magento y deseas actualizarla, tendrás que desinstalar la versión anterior e instalar la versión nueva. </p>
			<p>Para desinstalar la versión anterior debes:</p>
			<ul>
				<li>Acceder al panel de administración de Magento</li>
				<li>Ingresar a System -&gt; Magento Connect -&gt; Magento Connect Manager</li>
				<li>Buscar la extensión de Flow en el apartado Manage Existing Extensions</li>
				<li>Seleccionar la opción desinstalar</li>
				<li>Clic en Commit Changes</li>
			</ul>
			<p><strong>Para instalar la nueva versión</strong> debes seguir las mismas instrucciones del paso <strong>Descargar e Instalar</strong>. </p>
		</div>
		<div class="seccion fondo-claro">
			<div class="titulo-producto">
				<h2 id="target-5">Configuración del medio de pago Flow</h2>
			</div>
			<p>Para configurar la extensión de Flow para Magento debes dirigirte a System -&gt; Configuration -&gt; Payment Methods</p>
			<div align="center">
				<figure> <a href="images/soluciones/magento04.png" data-fancybox="group-img" data-caption="Acceso a forma de pago"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/magento04.png" alt="Acceso a forma de pago" /> </a>
					<figcaption>Acceso a forma de pago</figcaption>
				</figure>
			</div>
			<p>Buscar y abrir Flow en la lista <strong>Payment Methods</strong> y configurar los datos de la forma de pago</p>
			<div align="center">
				<figure> <a href="images/soluciones/magento05.png" data-fancybox="group-img" data-caption="Configurar forma de pago"> <img class="img-responsive img-rounded img-thumbnail" src="images/soluciones/magento05.png" alt="Configurar forma de pago" /> </a>
					<figcaption>Configurar forma de pago</figcaption>
				</figure>
			</div>
			<p>Los datos que debes configurar son:</p>
			<div class="table-responsive">
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Dato</th>
							<th>Descripción</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Título</td>
							<td>Ingresa el nombre que se mostrará a las personas cuando paguen en tu tienda virtual. Algunos ejemplos:<br>
								<ul>
									<li>Flow Webpay: Pagar con tarjetas de crédito o débito bancarias</li>
									<li>Flow Servipag: Pagar con tarjetas CMR, Ripley o Cencosud</li>
									<li>Flow Multicaja: Pagar en efectivo en locales adheridos a Multicaja</li>
									<li>Flow: Pagar mediante plataforma de pagos Flow con Webpay, Servipag y Multicaja</li>
								</ul>
							</td>
						</tr>
						<tr>
							<td>Activado</td>
							<td>Selecciona <strong>Si</strong> si quieres usar Flow</td>
						</tr>
						<tr>
							<td>ID Comercio Flow</td>
							<td>Ingresa el email con el que estás registrado en Flow</td>
						</tr>
						<tr>
							<td>Plataforma de Flow o Ambiente</td>
							<td>Selecciona si usarás la Plataforma de pruebas o la Plataforma oficial de Flow.<br>
								<strong>La plataforma de producción es la plataforma oficial</strong> donde se realizarán las transacciones. <br> Si antes deseas hacer pruebas selecciona la <strong>Plataforma de Pruebas</strong>. Para usar la Plataforma de Pruebas deberás registrarte en el sitio de pruebas <em>https://sandbox.flow.cl</em> y obtener el certificado digital desde ahí. Una vez concluyas de hacer pruebas, tendrás que configurar nuevamente la extensión con el certificado digital descargado del sitio oficial. </td>
						</tr>
						<tr>
							<td>Url de retorno</td>
							<td>Sólo aplica a la extensión de Multicaja. Corresponde a la página donde volverá el cliente una vez que generó el cupón de pago. Recomendamos que dicha url sea la página principal de tu tienda virtual.</td>
						</tr>
						<tr>
							<td>Tipo Integración</td>
							<td>Aquí debes seleccionar el tipo de integración deseado.<br>
								<ul>
									<li><strong>Ingresar directamente (Directo)</strong>: Corresponde al modo directo de integración. Una vez que el cliente confirme el pago en el sitio web del comercio, se abrirá inmediatamente la pantalla de pagos de Webpay, Servipag o Multicaja, según corresponda.</li>
									<li><strong>Mostrar pasarela Flow (Indirecto)</strong>: Corresponde al modo indirecto de integración. Previo al pago en Webpay, Servipag o Multicaja, se mostrará una ventana de Flow donde se indican los datos de la transacción (comercio, concepto, monto, email del pagador, etc). También se mostrarán al pagador los medios de pago que tenga habilitados el vendedor (Webpay, Servipag y/o Multicaja), pudiendo elegir el que desee.</li>
								</ul>
							</td>
						</tr>
						<tr>
							<td>Medio de pago</td>
							<td>Selecciona si deseas tener Webpay, Servipag, Multicaja o todos</td>
						</tr>
						<tr>
							<td>Llave privada Flow o Certificado</td>
							<td>Sube el archivo del Certificado Digital descargado desde Flow. </td>
						</tr>
						<tr>
							<td>Estado Orden Inicio Pago</td>
							<td>Selecciona Pending</td>
						</tr>
						<tr>
							<td>Estado Orden Exitosa</td>
							<td>Selecciona Processed Ogone Payment</td>
						</tr>
						<tr>
							<td>Estado Orden Fallida</td>
							<td>Selecciona Canceled</td>
						</tr>
						<tr>
							<td>Moneda Aceptada</td>
							<td>Selecciona Peso Chileno</td>
						</tr>
						<tr>
							<td>Logo</td>
							<td>Sube un logo asociado al medio de pago Flow</td>
						</tr>
						<tr>
							<td>Descripción</td>
							<td>Sube una descripción asociada al medio de pago</td>
						</tr>
						<tr>
							<td>Clic en Guardar configuración</td>
							<td>Para guardar tu configuración </td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="seccion fondo-claro">
	<div class="titulo-producto">
		<h2 id="target-ambiente">Validar configuración seleccionada</h2>
	</div>
	<p>Antes de comenzar a operar mediante Flow, te recomendamos validar la siguiente configuración:</p>
	<ul>
		<li> Si estás utilizando el sitio de pruebas (<a href="https://sandbox.flow.cl">https://sandbox.flow.cl</a>):
			<ol>
				<li> <b>Plataforma de Flow:</b> Debes seleccionar la opción "Plataforma de pruebas de Flow" </li>
				<li> <b>ID Comercio Flow:</b> Debes ingresar el email de la cuenta con que estás registrado en <a href="https://sandbox.flow.cl">https://sandbox.flow.cl</a> </li>
				<li> <b>Llave privada Flow:</b> Debes subir el último certificado digital descargado desde <a href="https://sandbox.flow.cl/app/web/certificado.php">https://sandbox.flow.cl/app/web/certificado.php</a> </li>
			</ol>
		</li>
		<li> Si estás utilizando el sitio de producción (<a href="https://www.flow.cl">https://www.flow.cl</a>):
			<ol>
				<li> <b>Plataforma de Flow:</b> Debes seleccionar la opción "Plataforma oficial de Flow" </li>
				<li> <b>ID Comercio Flow:</b> Debes ingresar el email de la cuenta con que estás registrado en <a href="https://www.flow.cl">https://www.flow.cl</a> </li>
				<li> <b>Llave privada Flow:</b> Debes utilizar el último certificado digital descargado desde <a href="http://www.flow.cl/app/web/certificado.php">http://www.flow.cl/app/web/certificado.php</a> </li>
			</ol>
		</li>
	</ul>
	<p> Si estás utilizando el sitio de pruebas (<a href="https://sandbox.flow.cl">https://sandbox.flow.cl</a>), puedes simular un pago mediante Webpay con las siguientes tarjetas:</p>
	<h4><strong>Pago Exitoso</strong></h4>
	<div class="table-responsive">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Dato</th>
					<th>Valor</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>N° Tarjeta de Crédito</td>
					<td>4051885600446623</td>
				</tr>
				<tr>
					<td>Año de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>Mes de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>CVV</td>
					<td>123</td>
				</tr>
				<tr>
					<td><strong>En la simulación del banco usar:</strong>
					</td>
					<td></td>
				</tr>
				<tr>
					<td>Rut</td>
					<td>11.111.111-1</td>
				</tr>
				<tr>
					<td>Clave</td>
					<td>123</td>
				</tr>
			</tbody>
		</table>
	</div>
	<h4><strong>Pago Rechazado</strong></h4>
	<div class="table-responsive">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Dato</th>
					<th>Valor</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>N° Tarjeta de Crédito</td>
					<td>5186059559590568</td>
				</tr>
				<tr>
					<td>Año de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>Mes de Expiración</td>
					<td>Cualquiera</td>
				</tr>
				<tr>
					<td>CVV</td>
					<td>123</td>
				</tr>
				<tr>
					<td><strong>En la simulación del banco usar:</strong>
					</td>
					<td></td>
				</tr>
				<tr>
					<td>Rut</td>
					<td>11.111.111-1</td>
				</tr>
				<tr>
					<td>Clave</td>
					<td>123</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>	</div>
	<!-- FOOTER -->
<div id="footer" class="footer">
    <div class="container visible-lg visible-md">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6">
                <h5>Preguntas frecuentes</h5>
                <ul class="unstyled">
                    <li><a href="faq.php#pagar">Pagar con Flow</a>
                    </li>
                    <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                    </li>
                    <li><a href="faq.php#ayuda">Ayuda técnica</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Tarifas y condiciones</h5>
                    <ul class="unstyled">
                        <li><a href="tarifas.php">Tarifas vigentes</a>
                        </li>
                        <li><a href="terminos.php">Términos &amp; condiciones</a>
                        </li>
                        <li><a href="privacidad.php">Política de privacidad</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6">
                <div>
                    <h5>Contacto</h5>
                    <ul class="unstyled">
                        <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                        </li>
                        <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-6 cajaLogos">
                <h5>En Flow recibes pagos con: </h5>
                <ul class="unstyled">
                    <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                    <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container hidden-lg hidden-md">
        <div class="panel-default" id="accordionFooter" role="tablist" aria-multiselectable="true">
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter1">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter1" aria-expanded="true" aria-controls="collapseFooter1"> <i class="more-less fa fa-chevron-down"></i> Preguntas frecuentes </a> </h4>
                </div>
                <div id="collapseFooter1" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter1">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="faq.php#pagar">Pagar con Flow</a>
                            </li>
                            <li><a href="faq.php#pago">Recibir pagos con Flow</a>
                            </li>
                            <li><a href="faq.php#ayuda">Ayuda técnica</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter2">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter2" aria-expanded="true" aria-controls="collapseFooter2"> <i class="more-less fa fa-chevron-down"></i> Tarifas y condiciones </a> </h4>
                </div>
                <div id="collapseFooter2" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter2">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tarifas.php">Tarifas vigentes</a>
                            </li>
                            <li><a href="terminos.php">Términos &amp; condiciones</a>
                            </li>
                            <li><a href="privacidad.php">Política de privacidad</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter3">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter3" aria-expanded="true" aria-controls="collapseFooter3"> <i class="more-less fa fa-chevron-down"></i> Contacto </a> </h4>
                </div>
                <div id="collapseFooter3" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter3">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li><a href="tel:+56 2 2583 0102">+56 2 2583 0102</a>
                            </li>
                            <li><a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">soporte@flow.cl</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter4">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter4" aria-expanded="true" aria-controls="collapseFooter4"> <i class="more-less fa fa-chevron-down"></i> En Flow recibes pagos con: </a> </h4>
                </div>
                <div id="collapseFooter4" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter4">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/webpay.php"><img src="/images/logos/webpay.png" class="logoWebpay" alt="logoWebpay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/onepay.php"><img src="/images/medios-de-pago/onepay/onepay.png" class="logoOnepay" alt="logoOnepay"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/servipag.php"><img src="/images/logos/servipag.png" class="logoServipag" alt="logoServipag"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/multicaja.php"><img src="/images/logos/multicaja.png" class="logoMulticaja" alt="logoMulticaja"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/mach.php"><img src="/images/medios-de-pago/mach/mach.png" class="logoMach" alt="logoMach"/></a> </li>
                            <li class="logosMediosPagos"> <a href="/cryptocompra.php"><img src="/images/medios-de-pago/cryptocompra/cryptocompra.png" class="logoCryptocompra" alt="logoCryptocompra"/></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="panel panelFooter">
                <div class="panel-heading" role="tab" id="headingFooter5">
                    <h4 class="panel-title"> <a role="button" data-toggle="collapse" data-parent="#accordionFooter" href="#collapseFooter5" aria-expanded="true" aria-controls="collapseFooter5"> <i class="more-less fa fa-chevron-down"></i> Seguridad </a> </h4>
                </div>
                <div id="collapseFooter5" class="panel-collapse collapse collapseFooter" role="tabpanel" aria-labelledby="headingFooter5">
                    <div class="panel-body">
                        <ul class="unstyled">
                            <li class="logosMediosPagos"> <a href="/seguro.php#sitelock"><img alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a> </li>
                            <li class="logosMediosPagos"> <a href="/seguro.php#pci"><img alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="socialFooter" class="social-footer" align="center">
    <div class="container">
        <div class="row">
            <div class="col-md-12"> 
                <div class="hidden-xs hidden-sm pull-left"><a href="/seguro.php#sitelock"><img class="img-responsive" alt="SiteLock" title="SiteLock" src="/images/sitelock.png"></a>
                </div>
                <a href="http://www.facebook.com/flow.cl" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-facebook fa-stack-1x"></i> </span></a> <a href="https://twitter.com/@flow_chile" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-twitter fa-stack-1x"></i> </span></a> <a href="https://www.instagram.com/flowpuntocl/" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-instagram fa-stack-1x"></i> </span></a> <a href="http://vimeo.com/flowvideos" target="_blank" class="hvr-grow"> <span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-vimeo fa-stack-1x"></i> </span></a> <a href="https://www.youtube.com/channel/UCIHMLt0pJDoTX19QJWpc5dg?view_as=subscriber" target="_blank" class="hvr-grow"><span class="fa-stack fa-lg"> <i class="fa fa-circle fa-stack-2x fa-inverse"></i> <i class="fa fa-youtube-play fa-stack-1x"></i> </span></a>
                <div class="hidden-xs hidden-sm pull-right"><a href="/seguro.php#pci"><img class="img-responsive" alt="PCI DSS Flow" title="PCI DSS Flow" src="/images/logo-pci-flow.png"></a>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- / FOOTER --> 

<!-- Modal Contactanos -->
<div class="modal fade" id="modalContactanos" tabindex="-1" role="dialog" aria-labelledby="modalContactanosLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>Contáctanos para mayor información </h2>
                </div>
            </div>
            <div class="modal-body">
                <p> ¿Quieres obtener este servicio? Puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<!-- Modal Pronto -->
<div class="modal fade" id="modalPronto" tabindex="-1" role="dialog" aria-labelledby="modalProntoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <div class="titulo-modal">
                    <h2>¡Pronto! </h2>
                </div>
            </div>
            <div class="modal-body">
                <p>Estamos trabajando en este servicio, pronto se encontrará disponible. </p>
                <p>Recuerda que puedes contactarnos mediante los siguientes medios, donde un ejecutivo te ayudará a resolver todas tus dudas: </p>
                <div class="row text-center">
                    <a href="tel:+56 2 2583 0102">
                        <p class="lead"><i class="fa fa-phone" aria-hidden="true"></i> +56 2 2583 0102</p>
                    </a>
                    <a href="mailto:soporte@flow.cl?subject=Solicitud de Soporte Flow">
                        <p class="lead"> <i class="fa fa-envelope-o" aria-hidden="true"></i> soporte@flow.cl</p>
                    </a>
                </div>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<!-- The scroll to top feature --> 
<a href="javascript:" id="return-to-top"> <i class="fa fa-chevron-up"> </i></a>	<!-- JS -->
	<script src="js/jquery-3.1.1.min.js"></script>
	<script src="js/fancybox/dist/jquery.fancybox.min.js"></script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery-1.11.3.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="js/bootstrap.3.3.7.min.js"></script>
	<!-- JS  -->
	<script src="secciones-pagina/footer.js"></script>
</body>

</html>